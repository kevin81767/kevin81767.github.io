/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: kevin
 *
 * Created on April 19, 2018, 12:08 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * 
 */

int i,s,choice,n=1;
int n_of_room=2;
int room_no;
FILE *p;

struct rooms{
    int roomNo;
    char type[10];
    int charge;
    char availability[2];
};

struct rooms rooms[2];

struct customers{
    char first_name[30];
    char last_name[30];
    int age;
    char phone_n[30];
    int room_no;
    int reserved_for;
    
};

struct customers cust[5];


// 1.See all rooms function

void All_Rooms(){
    p=fopen("room.room","r");

    printf("\n\n\t\t All rooms\t");
    printf("\t\t =========\n\n");
    printf("\t|\tRoom No\t|\tRoom Type\t|\tCharges\t\t|\tAvailable\t|\n");
    printf("\t------------------------------------------------------------------------------------------\n");
    while(!feof(p)){
        for(i=0;i<n_of_room;i++){
            fscanf(p,"%d\t%s\t%d\t%s\n",&rooms[i].roomNo,rooms[i].type,&rooms[i].charge,rooms[i].availability);
            printf("\t|\t%d\t|\t%s\t\t|\t%d\t\t|\t%s\t\n",rooms[i].roomNo,rooms[i].type,rooms[i].charge,rooms[i].availability);
        }
        
         
    }
  
    fclose(p);
}


// 2.Look for available rooms

void Availability(){
    
    p=fopen("room.room","r");

    printf("\n\n\t\t\tAvailable rooms\t\n");
    printf("\t\t-------------------------\n\n");
    printf("\t|\tRoom No\t|\tRoom Type\t|\tCharges\t\t|\tAvailable\t|\n");
    printf("\t------------------------------------------------------------------------------------------\n");
    while(!feof(p)){
        for(i=0;i<n_of_room;i++){
            fscanf(p,"%d\t%s\t%d\t%s\n",&rooms[i].roomNo,rooms[i].type,&rooms[i].charge,rooms[i].availability);
            if(strcmp(rooms[i].availability,"Y")==0){
                printf("\t|\t%d\t|\t%s\t\t|\t%d\t\t|\t%s\t\n",rooms[i].roomNo,rooms[i].type,rooms[i].charge,rooms[i].availability);
            }
        }      
    }
  
    fclose(p);
}

//Check if a given room is available

void room_avail(room_no){
    
    p=fopen("room.room","r");
    while(!feof(p)){
        for(i=0;i<n_of_room;i++){
            fscanf(p,"%d\t%s\t%d\t%s\n",&rooms[i].roomNo,rooms[i].type,&rooms[i].charge,rooms[i].availability);
            if(strcmp(rooms[i].roomNo,room_no)==0){
                if(strcmp(rooms[i].availability,"Y")!=0){
                    
//                    We return 3 if the room is not available
                    int o=3;
                    return o;
                
                    
                }
            }
        }      
    }
}


// 3. Room allocation

void Allocation(){
    p=fopen("customers.custom","a");
    
    for(i=0;i<n;i++){
        
        printf("\n Customer's first name :");
        scanf("%s",cust[i].first_name);
        printf("\n Customer's last name :");
        scanf("%s",cust[i].last_name);
        printf("\n Age of the customer: ");
        scanf("%d",&cust[i].age);
        printf("\n Phone number: ");
        scanf("%s",cust[i].phone_n);
        printf("Allocate room No: ");
        scanf("%d",&cust[i].room_no);
        printf("For how much days?(No of days) :");
        scanf("%d",&cust[i].reserved_for);
//        write in the file
        fprintf(p,"%s\t%s\t%d\t%s\t%d\t%d\n",cust[i].first_name,cust[i].last_name,cust[i].age,cust[i].phone_n,cust[i].room_no,cust[i].reserved_for);
        printf("__________________________________");
        printf("\n");
    }
    
    fclose(p);
    
}

// 4.Display all customers

void Customers(){
    
    p=fopen("customers.custom","r");

    printf("\t\t Customers");
    printf("\t----------------------\n\n");
    printf("\t|\tFirst name\t|\tLast name\t|\tAge\t|\tPhone number\t|\tRoom No\t|\tdays\t\n");
    printf("\t=====================================================================================================================\n");
    while(!feof(p)){
        for(i=0;i<1;i++){
            fscanf(p,"%s\t%s\t%d\t%s\t%d\t%d\n",cust[i].first_name,cust[i].last_name,&cust[i].age,cust[i].phone_n,&cust[i].room_no,&cust[i].reserved_for);
            printf("\t|\t\t%s\t|\t%s\t|\t%d\t|\t%s\t|\t%d\t|\t%d\t\n",cust[i].first_name,cust[i].last_name,cust[i].age,cust[i].phone_n,cust[i].room_no,cust[i].reserved_for);
        }
        
         
    }
  
    fclose(p);
}



int main() {
    
    printf("\t\t\t*************************************************************************************************************************************\n");
    printf("\t\t\tA modern and minimalist hotel surrounded by nature, a succession of rocky cliffs and sandy beaches offering an unforgettable view.\n");
    printf("\t\t\tA modern design that revolves around numerous architectural bodies.\n\t\t\tA minimalist style that shows an absolute contemporary state of being.\n\t\t\tA seaside resort that becomes a true model of architecture.\n\t\t\tThe purity and harmony of different architectural spaces to protect your privacy and the tranquility of your stay.\n");
    printf("\t\t\t*************************************************************************************************************************************\n");
    printf("\n\n\nEnter any Key to continue\n\n");
    getchar();
    do {
        printf("\n\n\t\t\tMENU\n");
        printf("\t\t =================\n");
        printf("\n");
        printf("\t\t 1. See all rooms\n");
        printf("\t\t 2. Rooms available\n");
        printf("\t\t 3. Book a room\n");
        printf("\t\t 4.Customers details\n\n\n");
        printf("Choose a number from the category: ");
        scanf("%d",&choice);
        
        
        switch (choice){
            case 1:
                All_Rooms();
                break;
            case 2:
                Availability();
                break;
            case 3:
                Allocation();
                break;
            case 4:
                Customers();
                break;
                
        }
    }
    while(choice != 9);
    

    return 0;
}

