<div class="container-fluid">
            <div class="row">
                <div class="footer">
                    <div class="wrapper">
                        <div class="container-fluid">

                        <div class="top-footer">
                            <div class="row">

                                <div class="col-md-4 col-lg-4 col-sm-4  col-xs-12 mission">
                                    <h2>Our Mission</h2>
                                    <p>"Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit porro modi nobis exercitationem dolore in nesciunt, et ratione esse, explicabo neque nostrum."</p>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-4  col-xs-12 social-media">
                                    <h2>Follow Us On:</h2>
                                    <i class="fa fa-facebook fa-2x"></i>
                                    <i class="fa fa-twitter fa-2x"></i>
                                    <i class="fa fa-linkedin fa-2x"></i>
                                    <i class="fa fa-instagram fa-2x"></i>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-4  col-xs-12">
                                    <h2>Contact Us</h2>
                                    <ul>
                                        <li><i style="color:white;" class="fa fa-map"></i> Remera KG45 St</li>
                                        <li><i class="fa fa-phone"></i> +250 784438186</li>
                                        <li><i class="fa fa-envelope"></i> ferwaba@gmail.com</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="copyright">
                        <p>Copyright &copy; Ferwaba. All Right reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
