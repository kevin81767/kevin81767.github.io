<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Meta Tag -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>	REG BBC ifite intego zo kwegukana igikombe yitabiriye bwa mbere, irerekeza muri Tanzania</title>
    <META NAME="Title" CONTENT="	REG BBC ifite intego zo kwegukana igikombe yitabiriye bwa mbere, irerekeza muri Tanzania">
	<META NAME="Keywords" CONTENT="	REG BBC ifite intego zo kwegukana igikombe yitabiriye bwa mbere, irerekeza muri Tanzania">
	<META NAME="Description" CONTENT="	REG BBC ifite intego zo kwegukana igikombe yitabiriye bwa mbere, irerekeza muri Tanzania">
	<META NAME="Subject" CONTENT="Amakuru ">
	<META NAME="Language" CONTENT="kinyarwanda">
	<meta name='copyright' content=''>
    <meta name="author" content="IT Devs Team, Hubert IT, Gilbert T">
    <meta name='designer' content='IT Devs Team'>
	<meta name='reply-to' content='devs@itdevs.rw'>
	<meta name='owner' content='IT Devs Ltd'>
    <meta property="og:url"           content="www.ijwiryacu.com" />
  	<meta property="og:type"          content="website" />
  	<meta property="og:title"         content="	REG BBC ifite intego zo kwegukana igikombe yitabiriye bwa mbere, irerekeza muri Tanzania" />
  	<meta property="og:description"   content="Ijwi Ryacu" />
  	<meta property="og:image"         content="" />
  	<meta property="og:author"        content="IT Devs Team" />
    <!-- External CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/main.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700" rel="stylesheet">
    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <script language="JavaScript">

	//////////F12 disable code////////////////////////
    document.onkeypress = function (event) {
        event = (event || window.event);
        if (event.keyCode == 123) {
           //alert('No F-12');
            return false;
        }
    }
    document.onmousedown = function (event) {
        event = (event || window.event);
        if (event.keyCode == 123) {
            //alert('No F-keys');
            return false;
        }
    }
document.onkeydown = function (event) {
        event = (event || window.event);
        if (event.keyCode == 123) {
            //alert('No F-keys');
            return false;
        }
    }
/////////////////////end///////////////////////


//Disable right click script
//visit http://www.rainbow.arch.scriptmania.com/scripts/
var message="Sorry, right-click has been disabled";
///////////////////////////////////
function clickIE() {if (document.all) {(message);return false;}}
function clickNS(e) {if
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers)
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
//
function disableCtrlKeyCombination(e)
{
//list all CTRL + key combinations you want to disable
var forbiddenKeys = new Array('a', 'n', 'c', 'x', 'v', 'j' , 'w');
var key;
var isCtrl;
if(window.event)
{
key = window.event.keyCode;     //IE
if(window.event.ctrlKey)
isCtrl = true;
else
isCtrl = false;
}
else
{
key = e.which;     //firefox
if(e.ctrlKey)
isCtrl = true;
else
isCtrl = false;
}
//if ctrl is pressed check if other key is in forbidenKeys array
if(isCtrl)
{
for(i=0; i<forbiddenKeys.length; i++)
{
//case-insensitive comparation
if(forbiddenKeys[i].toLowerCase() == String.fromCharCode(key).toLowerCase())
{
alert('Key combination CTRL + '+String.fromCharCode(key) +' has been disabled.');
return false;
}
}
}
return true;
}
</script>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

	<script type='text/javascript' src='//platform-api.sharethis.com/js/sharethis.js#property=5ae82a56d6704600179d6171&product=inline-share-buttons' async='async'></script>
   	</head>
	<body onload="startTime()" onkeypress="return disableCtrlKeyCombination(event);" onkeydown="return disableCtrlKeyCombination(event);">
	<?php require"header.php";?>

    <!-- page header -->
    <div class="page-header">
    <div class="wrapper-md container-fluid">
    Home > REG BBC ifite intego zo kwegukana igikombe yitabiriye bwa mbere, irerekeza muri Tanzania
    </div>
    </div>
    <!--  // page header -->



	<div class="wrapper-md container-fluid">
    	<div class="row">
        	<div class="col-lg-8 col-md-8">
            <!-- start read container-->
            <DIV class="read-container">

            	<div class="headline">REG BBC ifite intego zo kwegukana igikombe yitabiriye bwa mbere, irerekeza muri Tanzania</div>

            

                <div class="img">
                <img src="imgs/article.jpg">
                </div>

                <div class="share-container">
                <div class="sharethis-inline-share-buttons pull-left hid"></div>
                <div class="counts pull-right">
                <button class="btn btn-sm"><i class="fa fa-eye"></i> <views>132</views>
                 | <i class="fa fa-comments-o"></i> 20 </button></div>
                </div>

                <div class="content">

									<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><em><strong>Ikipe y&rsquo;umukino wa Basketball ya REG BBC ku nshuro ya mbere igiye kwitabira imikino y&rsquo;akarere ka Gatanu (Zone V) ihuza amakipe yitwaye neza iwayo izabera mu gihugu cya Tanzania Guhera tariki 30 Nzeri kugeza tariki 7 Ukwakira 2018.</strong></em></span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Ni ikipe ya REG BBC yegukanye igikombe cya shampiyona cy&rsquo;umwaka w&rsquo;imikino wa 2016-2017 ari nacyo cyayihesheje kuba yagararira u Rwanda mu mikino y&rsquo;akarere ka Gatanu y&rsquo;uyu mwaka aho iza guhaguruka ku kibuga cy&rsquo;indege cya Kanombe muri iri joro ku isaha ya saa Saba.</span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Nk&rsquo;uko umutoza mukuru w&rsquo;iyi kipe Ngwijuruvugo Richard Patrick abitangaza ngo intego yabo ni ukwegukana igikombe kandi ko biteguye neza n&rsquo;ubwo ari inshuro ya mbere bitabiriye iyi mikino nk&rsquo;ikipe ya REG.</span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Yagize ati &ldquo;<em>Ikipe tumaze iminsi dukora imyitozo uretse Mukengerwa Benjamin ufite ikibazo mu ivi ariko na we arimo kuvurwa, tuzamwifashisha muri Tanzania ariko abandi bakinnyi bameze neza. Intego haba ku bayobozi b&rsquo;ikipe, abatoza ndetse n&rsquo;abakinnyi ni ukujya kurushanwa kandi tukazana igikombe cya Zone 5.</em>&rdquo;</span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><img alt="JPEG - 71.6 kb" src="https://www.ruhagoyacu.com/local/cache-vignettes/L514xH640/42030650460_6357d74dac_z-450aa.jpg?1538080490" style="height:640px; width:514px" /></span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><strong>Mukenegerwa Benjamin ufite ikibazo mu ivi umutoza yizeye ko azabasha muri Tanzania</strong></span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">&ldquo;<em>Tugiye guserukira igihugu nka REG BBC ku nshuro yacu ya mbere ariko ntibivuze ko tutagenda ngo twitware neza kuko irushwanwa riba ari irushanwa kandi dufite abakinnyi bamenyereye amarushanwa kuko si ubwa mbere bazaba bayitabiriye ikizaba cyahindutse ni izina ry&rsquo;ikipe gusa kandi byose birashoboka kuko twiteguye neza</em>.&rdquo;- Ngwijuruvugo.</span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><img alt="JPEG - 93.1 kb" src="https://www.ruhagoyacu.com/local/cache-vignettes/L640xH459/29969056948_aaaf8243ff_z-36a10.jpg?1538080490" style="height:459px; width:640px" /></span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><strong>Umutoza mukuru wa REG BBC Ngwijuruvugo Richard</strong></span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">&ldquo;<em>Impamvu twongeye abakinnyi bashyashya ni uko dufite intego yo kuba twagera kure hashoboka muri iri rushanwa kandi muri iri rushanwa amakipe aba yemerewe kongeramo abakinnyi bakomeye kuko n&rsquo;ikipe nka City Oilers zajyaga zitabaza abakinnyi bavuye muri Amerika n&rsquo;ahandi natwe rero ni muri urwo rwego twongeyemo izindi mbaraga kugira ngo turebe ko twatwara igikombe.</em>&rdquo;- Richard Patrick.</span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Abakinny 5 nibo REG BBC yongeyemo badasanzwe bakina shampiyona yo mu Rwanda izifashisha muri iyi mikino harimo abanyarwanda nka Ruhezamihigo Hamza, Gasana Keneth, Manzi Dan Sorozo, umuyamerika Stephan Shephered ndetse na Belck Bell Engelbert wo muri Cameroun.</span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><img alt="JPEG - 112.2 kb" src="https://www.ruhagoyacu.com/local/cache-vignettes/L999xH736/image-6-2-2350e-2-87a5f.jpg?1538080490" style="height:736px; width:999px" /></span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><strong>Gasana Keneth nawe ari mubo REG BBC izifashisha mu mikino ya Zone V</strong></span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><img alt="JPEG - 107.9 kb" src="https://www.ruhagoyacu.com/local/cache-vignettes/L1000xH719/image-7-5704b-2-cd7f6.jpg?1538080490" style="height:719px; width:1000px" /></span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><strong>Manzi Dan nawe ni umwe mu bakinnyi bafite inararibonye uzifashishwa naREG BBC</strong></span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">REG BBC na Patriots BBC nizo zizahagararia u Rwanda mu cyiciro cy&rsquo;abagabo naho mu bagore u Rwanda rukazahagararirwa na APR WBBC.</span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Ikipe ya City Oilers yo muri Uganda yari yegukanye iri rushanwa umwaka ushize itsinze Patriots BBC yo mu Rwanda ku mukino wa nyuma kuri ubu ntabwo izitabira iyi mikino.</span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><strong>Amakipe azitabira imikino y&rsquo;akarere ka Gatanu:</strong></span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><strong>Abagabo:</strong>&nbsp;Al Ahly na Smouha (Egypt), Ethiopia Water na Wolekite City (Ethiopia), Kenya Ports Authority (KPA) na Strathmore (Kenya), Patriots na REG (Rwanda), hamwe na JKT na Oilers zo muri Tanzania.</span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><strong>Abagore:</strong>&nbsp;APR Women(Rwanda), WOLKITE City(Ethiopia), UCU(Uganda), JKT(Tanzania), BERCO STARS(Burundi), KPA(Kenya), na Equity Bank(Kenya).<br />
	Amakipe 2 ya mbere azabona itike y&rsquo;imikino Nyafurika izaba mu kwezi kwa mbere umwaka utaha.</span></span></p>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><strong>Abakinnyi ikipe ya REG BBC yajyanye muri Tanzania</strong></span></span></p>

	<ol>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Kubwimana Kazingufu Ali</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Mukengerwa Benjamin</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Nshobozwabyosenumukiza J.J.Wilson</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Kaje Elie</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Ruhezamihigo Hamza</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Habiyaremye Patrick</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Gasana Keneth</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Belck Bell Engelbert</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Ikishatse Herve</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Manzi Dan Sorozo</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Nkurunziza Chris Walter</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Nshizirungu Patrick</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Shyaka Olivier</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Kami Kabange</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Ncogoza Brunel</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Stephan Shephered</span></span></li>
		<li><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif">Ngandu Mbanze Bienvenue</span></span></li>
	</ol>

	<p><span style="font-size:14px"><span style="font-family:Arial,Helvetica,sans-serif"><strong>Umutoza mukuru</strong>: Ngwijuruvugo Richard Patrick&nbsp;<br />
	<strong>Umutoza wungirije</strong>: Kassim Karim</span></span></p>
                </div>
            </DIV>
            <!-- end read container -->

						<!-- add comment -->


						<!-- end comment -->


            </div>

		<?php //require"inc/latest.php";?>



        <?php //require"inc/most-read.php";?>
        </div>
    </div>
	<?php require"footer.php";?>
	<script src="assets/js/jquery.timeago.js"></script>
    <script type="text/javascript">
	jQuery(document).ready(function() {
  		jQuery("time.timeago").timeago();
	});
	</script>
  	<script src="assets/js/wow.js"></script>
  	<script>
    wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
          console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();
    document.getElementById('moar').onclick = function() {
      var section = document.createElement('section');
      section.className = 'section--purple wow fadeInDown';
      this.parentNode.insertBefore(section, this);
    };
  </script>


</body>
</html>
