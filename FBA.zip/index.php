<!DOCTYPE html>
<html lang="en">

<head>

    <title>Ferwaba</title>
    <META NAME="Title" CONTENT="">
	  <META NAME="Keywords" CONTENT="">
	  <META NAME="Description" CONTENT="">
	  <META NAME="Subject" CONTENT="Amakuru ">
	  <META NAME="Language" CONTENT="kinyarwanda">
	  <meta name='copyright' content='Ferwaba'>
    <meta name="author" content="IT Devs Team">
    <meta name='designer' content='IT Devs Team'>
	  <meta name='reply-to' content='devs@itdevs.rw'>
	  <meta name='owner' content='IT Devs Ltd'>
    <meta property="og:url"           content="" />
  	<meta property="og:type"          content="website" />
  	<meta property="og:title"         content="" />
  	<meta property="og:description"   content="" />
  	<meta property="og:image"         content="" />
  	<meta property="og:author"        content="IT Devs Team" />
    <!-- External CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/main.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700" rel="stylesheet">
    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.png">
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <style media="screen">
      .results{
        font-size: 20px;
        font-weight: bolder;
      }

      .team{
        padding: 10px;
        height: 30px;
      }

      h2{
        font-size: 18px;
        font-weight: bold;
        padding: 0px;
        margin: 0px;
        color: #d96926;
      }

      .img{
        padding: 10px;
        width: 100px;
      }

      .dropdown-menu li a{
        background: #d96926 !important;
      }

      .announcement{
        margin-top: 5px;
        font-size: 18px;
        border-bottom: solid 1px #888888;
        padding-bottom: 10px;
      }
    </style>

</head>
<body onload="startTime()" onkeypress="return disableCtrlKeyCombination(event);" onkeydown="return disableCtrlKeyCombination(event);">
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.1&appId=206925953176329&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));
</script>

  <div id="header">
    <!-- welcome headline sliding start -->



    <!-- start navigation bar -->
    <nav class="navbar navbar-inverse">
      <div class="navbar-wrapper">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="navigation">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#"><img width=200 src="assets/images/ferwaba-logo-header.png" class="logo-header"></a>
          </div>
          <div class="collapse navbar-collapse" id="navigation">
            <ul class="nav navbar-nav">
              <li class="active"><a href=""> Home </a></li>
              <li><a href="#" class="dropdown-toggle" data-toggle="dropdown">About Ferwaba</a>
                <ul class="dropdown-menu">
                  <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Organigram/Structure</a>
                    <ul class="dropdown-menu">
                      <li><a href="#">General assembly</a></li>
                      <li><a href="#">Executive commitee</a></li>
                      <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown" >Commissions</a>
                        <ul class="dropdown-menu">
                          <li><a href="#">Technical and Competition</a></li>
                          <li><a href="#">Medical</a></li>
                          <li><a href="#">Legal</a></li>
                          <li><a href="#">Women</a></li>
                          <li><a href="#">Youth Development</a></li>
                          <li><a href="#">Marketing</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Office</a></li>
                      <li><a href="#">Advisors</a></li>
                      <li><a href="#">Auditors</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown" >Coaches</a>
                    <ul class="dropdown-menu">
                      <li><a href="#">Database</a></li>
                      <li><a href="#">How to become a coach?</a></li>
                      <li><a href="#">Training materials</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown" >Officials</a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Database</a></li>
                        <li><a href="#">How to become an official</a></li>
                        <li><a href="#">Training materials</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown" >Documents</a>
                    <ul class="dropdown-menu">
                      <li><a href="#">Reglements generaux des competitions (FERWAFA)</a></li>
                      <li><a href="#">FIBA rules and regulations</a></li>
                      <li><a href="#">Reglements d'ordre interieur (FERWAFA)</a></li>
                      <li><a href="#">Reports,action plans,strategic plans</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
              <li><a href="dropdown" class="dropdown-toggle" data-toggle="dropdown">Competitions</a>

                <ul class="dropdown-menu">
                  <li><a href="#">National League</a></li>
                  <li><a href="#">Gisembe</a></li>
                  <li><a href="#">Playoffs</a></li>
                  <li><a href="#">Pre-seasons</a></li>
                </ul>

              </li>
              <li><a class="dropdown-toggle" href="#" data-toggle="dropdown">National</a>
                <ul class="dropdown-menu">
                  <li><a href="#">Man senior</a></li>
                  <li><a href="#">Woman senior</a></li>
                  <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Junior Teams</a>
                    <ul class="dropdown-menu">
                      <li class="dropdown-submenu"><a class="dropdown-toggle" data-toggle="dropdown"> Boys</a>
                        <ul class="dropdown-menu">
                          <li><a href="#">Under 18</a></li>
                          <li><a href="#">Under 16</a></li>
                        </ul>
                      </li>
                      <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown"> Girls</a>
                        <ul class="dropdown-menu">
                          <li><a href="#">Under 18</a></li>
                          <li><a href="#">Under 16</a></li>
                        </ul>
                      </li>
                    </ul>

                  </li>
                </ul>
              </li>
              <li><a href="#">3 X 3</a></li>
              <li><a href="#">Live Stats</a></li>
              <li><a class="dropdown-toggle" href="#" data-toggle="dropdown">Development</a>
                <ul class="dropdown-menu">
                  <li><a href="#">Photo</a></li>
                  <li><a href="#">Video</a></li>
                </ul>
              </li>
              <li><a href="#">Contact</a></li>
              <form class="navbar-form navbar-left">
                <div class="input-group has-search">
                  <input type="text" class="form-control" placeholder="Search">
                  <div class="input-group-btn">
                    <button class="btn btn-default" type="submit">
                      <i style="color:orange;" class="fa fa-search"></i>
                    </button>
                  </div>
                </div>
              </form>
            </ul>
          </div>
        </div>
      </div>
    </nav>
    <!-- end wrapper--->
    </nav>
    <!-- end navigation--->
    </div>
    <!-- end header -->

    <!-- end mobile-->
	<div class="wrapper body container-fluid">
	<div class="home-container">
    	<div class="row">

        <div class="col-md-12">
          <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="slides/4.jpg" alt="Chania">
    </div>

    <div class="item">
      <img src="slides/3.jpg" alt="Chania">
    </div>

    <div class="item">
      <img src="slides/1.jpg" alt="Chania">
    </div>

  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
        </div>

      </div>
      <br>
      <br>
      <div class="live-stat">
        <h2>Banner for live stats</h2>
      </div>




      <div class="row">

        <div class="col-md-5 col-sm-12 col-xs-12">
          <div class="col-1-row-2">
            <center>
              <h2>News</h2>

            </center>

            <table>
              <tr>
                <td class="img"> <img src="imgs/news/1.jpg" class="img-responsive" alt=""> </td>
                <td class="headline" onclick="location.href='read.php'">REG BBC ifite intego zo kwegukana igikombe yitabiriye bwa mbere, irerekeza muri Tanzania</td>
              </tr>

              <tr>
                <td class="img"> <img src="imgs/news/2.jpg" class="img-responsive" alt=""> </td>
                <td class="headline">FIBAWC: U Rwanda rwasoje imikino ibanza yo gushaka itike y’igikombe cy’isi rudatsinze</td>
              </tr>

              <tr>
                <td class="img"> <img src="imgs/news/3.jpg" class="img-responsive" alt=""> </td>
                <td class="headline">FIBAWC: U Rwanda rwasoje imikino ibanza yo gushaka itike y’igikombe cy’isi rudatsinze</td>
              </tr>

              <tr>
                <td class="img"> <img src="imgs/news/4.jpg" class="img-responsive" alt=""> </td>
                <td class="headline">Basketball: Abakinnyi 12 ikipe y’igihugu yahagurukanye yerekeza muri Nigeria gushaka itike y’igikombe cy’isi</td>
              </tr>
            </table>

          </div>
        </div>


        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="col-1-row-2">

            <center>
              <h2>Match updates</h2>
              <table  width="100%">
                <tr>
                  <td width="50" height="30"> <img src="imgs/teams/1.png" class="img-responsive team-logo"alt=""> </td>
                  <td class="team">Espoir</td>
                  <td class="results" width="30">59</td>
                  <td class="results" width="30">64</td>
                  <td class="team">IPRC - SOUTH</td>
                  <td width="50"> <img src="imgs/teams/2.jpg" class="img-responsive team-logo"alt=""></td>
                </tr>
                <tr>
                  <td width="50" height="30"> <img src="imgs/teams/3.jpg" class="img-responsive team-logo"alt=""> </td>
                  <td class="team">Patriots</td>
                  <td class="results" width="30">82</td>
                  <td class="results" width="30">66</td>
                  <td class="team">UGB </td>
                  <td width="50"> <img src="imgs/teams/4.jpg" class="img-responsive team-logo"alt=""></td>
                </tr>

                <tr>
                  <td width="50" height="30"> <img src="imgs/teams/5.PNG" class="img-responsive team-logo"alt=""> </td>
                  <td class="team">IPRC - Kigali</td>
                  <td class="results" width="30">81</td>
                  <td class="results" width="30">84</td>
                  <td class="team"> APR BBC</td>
                  <td width="50"> <img src="imgs/teams/6.jpg" class="img-responsive team-logo"alt=""></td>
                </tr>

                <tr>
                  <td width="50" height="30"> <img src="imgs/teams/7.jpg" class="img-responsive team-logo"alt=""> </td>
                  <td class="team">REG</td>
                  <td class="results" width="30">68</td>
                  <td class="results" width="30">84</td>
                  <td class="team"> APR BBC</td>
                  <td width="50"> <img src="imgs/teams/6.jpg" class="img-responsive team-logo"alt=""></td>
                </tr>

              </table>

            </center>
          </div>
        </div>



        <div class="col-md-3 col-sm-2">
          <div class="col-1-row-2">
            <center>
            <h3 style="text-align:center; background-color:#333;color:white;">Fiba</h3>
              <img src="imgs/startimes.jpg" class="img-responsive">
            </center>
          </div>
          </div>
        </div>



      <!-- end row -->

      <div class="row">
        <div class="col-md-12">
          <div class="banner-container">
            <br>
            <center>
              <h2>Banner</h2>

            </center>
          </div>
        </div>
      </div>



            <div class="row">

              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="col-1-row-2">
                  <center>
                    <h2>Events</h2>

                    <img src="imgs/events.png" class="img-responsive" alt="">

                  </center>

                </div>
              </div>


              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="col-1-row-2">

                  <center>
                    <h2>Announcements</h2>

                  </center>

                  <div class="announcement">
                    Patriots BBC yerekeje muri Tanzania mu mikino ya zone 5
                  </div>

                  <div class="announcement">
                    Basketball: U Rwanda rwasoje imikino nyafurika ku mwanya wa Gatandatu, Mali yegukana igikombe
                  </div>

                  <div class="announcement">
                    Icyinyuranyo cy’inota rimwe gitumye u Rwanda rutakaza umukino wa gatatu mu mikino y’ingimbi
                  </div>

                </div>
              </div>



              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="col-1-row-2">
                  <center>
                    <div class="fb-page" data-href="https://web.facebook.com/Ferwaba/" data-tabs="timeline" data-height="270" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://web.facebook.com/Ferwaba/" class="fb-xfbml-parse-ignore"><a href="https://web.facebook.com/Ferwaba/">Ferwaba</a></blockquote></div>

                  </center>
                </div>
                </div>
              </div>


                    <div class="row">
                      <div class="col-md-12">
                        <div class="banner-container">
                          <br>
                          <center>
                          <h2>Banner</h2>
                        </div>
                      </center>
                      </div>
                    </div>
    <div class="row">
        <div class="col-md-12">
        <h3>Galerry / Photo</h3>

        <div class="row">
          <script src="js/jssor.slider-27.5.0.min.js" type="text/javascript"></script>
      <script type="text/javascript">
          jssor_1_slider_init = function() {

              var jssor_1_options = {
                $AutoPlay: 1,
                $AutoPlaySteps: 5,
                $SlideDuration: 160,
                $SlideWidth: 200,
                $SlideSpacing: 3,
                $ArrowNavigatorOptions: {
                  $Class: $JssorArrowNavigator$,
                  $Steps: 5
                },
                $BulletNavigatorOptions: {
                  $Class: $JssorBulletNavigator$
                }
              };

              var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

              /*#region responsive code begin*/

              var MAX_WIDTH = 980;

              function ScaleSlider() {
                  var containerElement = jssor_1_slider.$Elmt.parentNode;
                  var containerWidth = containerElement.clientWidth;

                  if (containerWidth) {

                      var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                      jssor_1_slider.$ScaleWidth(expectedWidth);
                  }
                  else {
                      window.setTimeout(ScaleSlider, 30);
                  }
              }

              ScaleSlider();

              $Jssor$.$AddEvent(window, "load", ScaleSlider);
              $Jssor$.$AddEvent(window, "resize", ScaleSlider);
              $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
              /*#endregion responsive code end*/
          };
      </script>
      <style>
          /*jssor slider loading skin spin css*/
          .jssorl-009-spin img {
              animation-name: jssorl-009-spin;
              animation-duration: 1.6s;
              animation-iteration-count: infinite;
              animation-timing-function: linear;
          }

          @keyframes jssorl-009-spin {
              from { transform: rotate(0deg); }
              to { transform: rotate(360deg); }
          }

          /*jssor slider bullet skin 057 css*/
          .jssorb057 .i {position:absolute;cursor:pointer;}
          .jssorb057 .i .b {fill:none;stroke:#fff;stroke-width:2000;stroke-miterlimit:10;stroke-opacity:0.4;}
          .jssorb057 .i:hover .b {stroke-opacity:.7;}
          .jssorb057 .iav .b {stroke-opacity: 1;}
          .jssorb057 .i.idn {opacity:.3;}

          /*jssor slider arrow skin 073 css*/
          .jssora073 {display:block;position:absolute;cursor:pointer;}
          .jssora073 .a {fill:#ddd;fill-opacity:.7;stroke:#000;stroke-width:160;stroke-miterlimit:10;stroke-opacity:.7;}
          .jssora073:hover {opacity:.8;}
          .jssora073.jssora073dn {opacity:.4;}
          .jssora073.jssora073ds {opacity:.3;pointer-events:none;}
      </style>
      <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:150px;overflow:hidden;visibility:hidden;">
          <!-- Loading Screen -->
          <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
              <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/spin.svg" />
          </div>
          <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:150px;overflow:hidden;">
              <div>
                  <img data-u="image" src="img/001.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/005.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/006.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/007.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/009.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/001.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/005.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/006.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/007.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/009.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/001.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/005.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/006.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/007.jpg" />
              </div>
              <div>
                  <img data-u="image" src="img/009.jpg" />
              </div>
          </div>
          <!-- Bullet Navigator -->
          <div data-u="navigator" class="jssorb057" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
              <div data-u="prototype" class="i" style="width:16px;height:16px;">
                  <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                      <circle class="b" cx="8000" cy="8000" r="5000"></circle>
                  </svg>
              </div>
          </div>
          <!-- Arrow Navigator -->
          <div data-u="arrowleft" class="jssora073" style="width:50px;height:50px;top:0px;left:30px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
              <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                  <path class="a" d="M4037.7,8357.3l5891.8,5891.8c100.6,100.6,219.7,150.9,357.3,150.9s256.7-50.3,357.3-150.9 l1318.1-1318.1c100.6-100.6,150.9-219.7,150.9-357.3c0-137.6-50.3-256.7-150.9-357.3L7745.9,8000l4216.4-4216.4 c100.6-100.6,150.9-219.7,150.9-357.3c0-137.6-50.3-256.7-150.9-357.3l-1318.1-1318.1c-100.6-100.6-219.7-150.9-357.3-150.9 s-256.7,50.3-357.3,150.9L4037.7,7642.7c-100.6,100.6-150.9,219.7-150.9,357.3C3886.8,8137.6,3937.1,8256.7,4037.7,8357.3 L4037.7,8357.3z"></path>
              </svg>
          </div>
          <div data-u="arrowright" class="jssora073" style="width:50px;height:50px;top:0px;right:30px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
              <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                  <path class="a" d="M11962.3,8357.3l-5891.8,5891.8c-100.6,100.6-219.7,150.9-357.3,150.9s-256.7-50.3-357.3-150.9 L4037.7,12931c-100.6-100.6-150.9-219.7-150.9-357.3c0-137.6,50.3-256.7,150.9-357.3L8254.1,8000L4037.7,3783.6 c-100.6-100.6-150.9-219.7-150.9-357.3c0-137.6,50.3-256.7,150.9-357.3l1318.1-1318.1c100.6-100.6,219.7-150.9,357.3-150.9 s256.7,50.3,357.3,150.9l5891.8,5891.8c100.6,100.6,150.9,219.7,150.9,357.3C12113.2,8137.6,12062.9,8256.7,11962.3,8357.3 L11962.3,8357.3z"></path>
              </svg>
          </div>
      </div>
      <script type="text/javascript">jssor_1_slider_init();</script>
        </div>
        </div>

    </div>

    <div class="row">
        <div class="col-md-12">
        <h3>Video</h3>

        <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="video-container">
              <iframe width="100%" height="100%" src="https://www.youtube.com/embed/5CeoxXu9ut8" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="video-container">
              <iframe width="100%" height="100%" src="https://www.youtube.com/embed/I8O91X9epeI" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="video-container">
              <iframe width="100%" height="100%" src="https://www.youtube.com/embed/YQPoB1UOgC0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
            </div>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="video-container">
              <iframe width="100%" height="100%" src="https://www.youtube.com/embed/jQ57ZQFClco" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
            </div>
          </div>
        </div>
        </div>

    </div>
    </div>

    </div>

    </div>

 	<?php require"footer.php";?>

	<script src="assets/js/jquery.timeago.js"></script>
    <script type="text/javascript">
	jQuery(document).ready(function() {
  		jQuery("time.timeago").timeago();
	});
	</script>
  	<script src="assets/js/wow.js"></script>
  	<script>
    wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
          console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();
    document.getElementById('moar').onclick = function() {
      var section = document.createElement('section');
      section.className = 'section--purple wow fadeInDown';
      this.parentNode.insertBefore(section, this);
    };
  </script>
  <script type='text/javascript'>
    (function(){ var widget_id = 'PumZD5C4ah';var d=document;var w=window;function l(){
    var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
  </script>
<!-- {/literal} END JIVOSITE CODE -->


</body>
</html>
