
	<div id="header">
    <!-- welcome headline sliding start -->



    <!-- start navigation bar -->
    <nav class="navbar navbar-inverse">
    <div class="navbar-wrapper">
  	<div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="navigation">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"><img src="assets/images/ferwaba-logo-header.png" class="logo-header"></a>
    </div>
    <div class="collapse navbar-collapse" id="navigation">
      <ul class="nav navbar-nav">
        <li class="active"><a href=""> Home </a></li>
        <li><a href="">About Ferwaba</a></li>
        <li ><a class="dropdown-toggle" data-toggle="dropdown">Competitions</a>

					<ul class="dropdown-menu">
          <li><a href="#">National League</a></li>
          <li><a href="#">Gisembe</a></li>
          <li><a href="#">Playoffs</a></li>
					<li><a href="#">Pre-seasons</a></li>
        </ul>

				</li>
        <li><a class="dropdown-toggle" data-toggle="dropdown">Team</a>

					<ul class="dropdown-menu">
					<li><a href="#">Man senior</a></li>
					<li><a href="#">Woman senior</a></li>
					<li><a href="#">Junior Teams</a></li>
					</ul>

			</li>
        <li><a class="dropdown-toggle" data-toggle="dropdown">Live</a>
					<ul class="dropdown-menu">
					<li><a href="#">Local Games</a></li>
					<li><a href="#">International</a></li>
					</ul>
				</li>
        <li><a class="dropdown-toggle" data-toggle="dropdown">Media</a>
					<ul class="dropdown-menu">
					<li><a href="#">Photo</a></li>
					<li><a href="#">Video</a></li>
					</ul></li>
        <li><a href="">Pending List</a></li>
      </ul>

			<ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="fa fa-facebook"></span> </a></li>
      <li><a href="#"><span class="fa fa-twitter"></span> </a></li>
			<li><a href="#"><span class="fa fa-instagram"></span> </a></li>
      <li><a href="#"><span class="fa fa-whatsapp"></span> </a></li>
    	</ul>

    </div>
  	</div>
    </div>
    <!-- end wrapper--->
	</nav>
    <!-- end navigation--->
    </div>
    <!-- end header -->
