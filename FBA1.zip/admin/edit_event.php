<?php
if(isset($_SESSION['admin'])){
    if($_SESSION['admin']['level']=="Administrator"){
        if(isset($_GET['id'])){

            require "class/Database.php";
            require "class/Events.php";

            $id=$_GET['id'];
            $datas=New Events();
            $res=$datas->eventBy_Id($id);
            if($res){
                $title=$res[0]->title;
                $content=$res[0]->content;
                $date_of_e=$res[0]->date_of_event;
                require 'modules/events_update.php';
                ?>
                <form action="#" method="POST" class="form-inline" enctype="multipart/form-data">
                    <div class="form-group">
                        <input type="text" name="title" placeholder="Name of the event" value="<?=$title;?>" class="form-control">
                        <input type="text" class="form-control" name="date_event" id="date_match" placeholder="On" value="<?=$date_of_e;?>" required >
                    </div>
                    <br>
                    <textarea name="editor" class="ckeditor"><?=$content;?></textarea>
                    <button type="submit" class="btn btn-info btn-block">Submit</button>
                </form>
                <?php
            }
            else{
                ?>
                <div class="alert alert-warning">
                    <i class="fa fa-exclamation-circle"></i> The page you are requesting is not available.Please contact the WebMaster.
                </div>
                <?php
            }

        }
    }
}