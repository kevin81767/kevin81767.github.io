<?php
if(isset($_GET['p'])){
    if($_GET['p']=='home'){
        require "home.php";
    }

    elseif($_GET['p']=="read"){
        require "read.php";
    }
    elseif($_GET['p']=="category"){
        require "category.php";
    }
    else{
        require "404.php";
    }
}
else{
    require "home.php";
}
