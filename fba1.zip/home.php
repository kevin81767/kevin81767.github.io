<?php
require 'class/Database.php';
require 'class/Announcements.php';
require 'class/Events.php';
require 'class/Update.php';
require 'class/News.php';
$announ=New Announcements();
$event=New Events();
$new=New News();
$update=New Update();
?>
<br>
<br>
<br>
<br>
<div class="row">
    <div class="col-md-12">
        <div class="banner-container">
            <div id = "spw_920J9U9N18P8RJXLDYF6HMM010LDU7"></div>
        </div>
    </div>
</div>
<div class="wrapper body container-fluid">
<div class="home-container">
    <div class="row">

    <div class="col-md-12">
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
        </ol>

<!-- Wrapper for slides -->
<div class="carousel-inner" role="listbox">
<div class="item active">
    <img src="slides/Screenshot_2018-11-07-16-49-03-1.png" alt="Chania">
</div>

<div class="item">
    <img src="slides/Screenshot_2018-11-07-16-49-49-1.png" alt="Chania">
</div>

<div class="item">
    <img src="slides/Screenshot_2018-11-09-13-48-28-1.png" alt="Chania">
</div>
<div class="item">
    <img src="slides/Screenshot_2018-11-09-13-48-45-1.png" alt="Chania">
</div>
<div class="item">
    <img src="slides/Screenshot_2018-11-09-13-48-56-1.png" alt="Chania">
</div>
</div>

<!-- Left and right controls -->
<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
<span class="sr-only">Previous</span>
</a>
<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
<span class="sr-only">Next</span>
</a>
</div>
    </div>

    </div>
    <br>
    <br>
    <div class="row">

    <div class="col-md-4 col-sm-12 col-xs-12">
        <div class="col-1-row-2">
        <center>
            <h2>News</h2>

        </center>

        <table class="section-news">
            <?php
            $res_news=$new->retrieveNews();
            if($res_news){
                foreach ($res_news as $resN) {
                    ?>
                    <tr style="height:90px;">
                        <td class="img"> <img src="modules/covers/<?=$resN['cover_pic'];?>" class="img-responsive" alt=""> </td>
                        <td class="headline" ><a style="color:rgb(134, 131, 131);" href="index.php?p=read&amp;id=<?=$resN['id'];?>"><?=$resN['title'];?> <a href="index.php?p=read&amp;id=<?=$resN['id'];?>"></a></td>
                    </tr>
                    <?php
                }
            }
            ?>
            <!-- <tr>
                <td class="img"> <img src="imgs/news/2.jpg" class="img-responsive" alt=""> </td>
                <td class="headline">FIBAWC: U Rwanda rwasoje imikino ibanza yo gushaka itike y’igikombe cy’isi rudatsinze</td>
            </tr>

            <tr>
                <td class="img"> <img src="imgs/news/3.jpg" class="img-responsive" alt=""> </td>
                <td class="headline">FIBAWC: U Rwanda rwasoje imikino ibanza yo gushaka itike y’igikombe cy’isi rudatsinze</td>
            </tr>

            <tr>
                <td class="img"> <img src="imgs/news/4.jpg" class="img-responsive" alt=""> </td>
                <td class="headline">Basketball: Abakinnyi 12 ikipe y’igihugu yahagurukanye yerekeza muri Nigeria gushaka itike y’igikombe cy’isi</td>
            </tr> -->
        </table>

        </div>
    </div>


    <div class="col-md-5 col-sm-12 col-xs-12">
        <div class="col-1-row-2">

        <center>
            <h2>Match updates</h2>
            <table  width="100%">
            <?php
            $datas=$update->retrieveMatch();
            if($datas){
                foreach ($datas as $res) {
                    switch ($res['f_team']) {
                        case 'Espoir':
                            $image='1.png';
                            break;
                        case 'Patriots':
                            $image='3.jpg';
                            break;
                        case 'IPRC-Kigali':
                            $image='5.png';
                            break;
                        case 'REG':
                            $image='7.jpg';
                            break;
                        case 'IPRC-SOUTH':
                            $image='2.jpg';
                            break;
                        case 'UGB':
                            $image='4.jpg';
                            break;
                        case 'APR_BBC':
                            $image='6.jpg';
                            break;
                    }
                    switch ($res['s_team']) {
                        case 'Espoir':
                            $image2='1.png';
                            break;
                        case 'Patriots':
                            $image2='3.jpg';
                            break;
                        case 'IPRC-Kigali':
                            $image2='5.png';
                            break;
                        case 'REG':
                            $image2='7.jpg';
                            break;
                        case 'IPRC-SOUTH':
                            $image2='2.jpg';
                            break;
                        case 'UGB':
                            $image2='4.jpg';
                            break;
                        case 'APR_BBC':
                            $image2='6.jpg';
                            break;
                    }
                    ?>
                    <tr>
                        <td width="50" height="30"> <img src="imgs/teams/<?=$image;?>" class="img-responsive team-logo"alt=""> </td>
                        <td class="team"><?=$res['f_team'];?></td>
                        <td class="results" width="30"><?=$res['f_score'];?></td>
                        <td class="results" width="30"><?=$res['s_score'];?></td>
                        <td class="team"><?=$res['s_team'];?></td>
                        <td width="50"> <img src="imgs/teams/<?=$image2;?>" class="img-responsive team-logo"alt=""></td>
                    </tr>
                    <?php
                }
            }
            ?>
            </table>

        </center>
        </div>
    </div>



    <div class="col-md-3 col-sm-12 hidden-md">
            <center>
            <br>
            <br>
            <br>

                <a href="http://fiba.basketball"><img src="image livestate/fiba-logo.png" alt="" class="img-responsive"></a>
                <img src="imgs/startimes.jpg" class="img-responsive">
            </center>
    </div>
    </div>
</div>


    <!-- end row -->

    <div class="row">
    <div class="col-md-12">
        <div class="banner-container">
        <br>
        <center>
            <h2>Banner</h2>

        </center>
        </div>
    </div>
    </div>


        <div class="row">

            <div class="col-md-4 col-sm-12 col-xs-12">
            <div class="col-1-row-2">
                <center>
                <h2>Upcoming events</h2>
                <br>
                <div class="event">
                    <div class="event-e">
                        <?php
                        $resul=$event->retrieveEvents();
                        if($resul){
                            foreach ($resul as $res) {
                                $date=strtotime($res['date_of_event']);
                                $day=date('d',$date);
                                $month=date('M',$date);
                                $year=date('y',$date);
                                ?>
                                <h2 id="event-o">
                                    <span class="date">
                                        <span class="month">
                                        <?=$month;?>
                                        </span>
                                        <span class="day">
                                        <?=$day;?>
                                        </span>
                                    </span>
                                    <span class="meta"><a style="color:#666;" href="index.php?p=event&amp;id=<?=$res['id'];?>"><?=$res['title'];?></a></span>
                                </h2>
                                <hr>
                                <?php

                            }
                        }
                        ?>
                    </div>
                </div>

                </center>

            </div>
            </div>


            <div class="col-md-4 col-sm-12 col-xs-12">
            <div class="col-1-row-2">

                <center>
                <h2>Announcements</h2>

                </center>
                <?php
                $resAnn=$announ->retrieveAnnounces();
                if($resAnn){
                    foreach ($resAnn as $res_A) {
                        $res_A['content']=strip_tags($res_A['content']);
                        ?>
                        <div class="announcement">
                            <h2><a href="index.php?p=announcement&amp;id=<?=$res_A['id'];?>" style="color:#666;"><?=$res_A['title'];?></a></h2>
                        </div>
                        <?php
                    }
                }
                ?>

            </div>
            </div>



            <div class="col-md-4 col-sm-12 col-xs-12">
            <div class="col-1-row-2">
                <center>
                <div class="fb-page" data-href="https://web.facebook.com/Ferwaba/" data-tabs="timeline" data-height="270" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://web.facebook.com/Ferwaba/" class="fb-xfbml-parse-ignore"><a href="https://web.facebook.com/Ferwaba/">Ferwaba</a></blockquote></div>

                </center>
            </div>
            </div>
            </div>


                <div class="row">
                    <div class="col-md-12">
                    <div class="banner-container">
                        <br>
                        <center>
                        <h2>Banner</h2>
                    </div>
                    </center>
                    </div>
                </div>
<div class="row">
    <div class="col-md-12">
    <h3>Galerry / Photo</h3>

    <div class="row">
        <script src="js/jssor.slider-27.5.0.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        jssor_1_slider_init = function() {

            var jssor_1_options = {
            $AutoPlay: 1,
            $AutoPlaySteps: 5,
            $SlideDuration: 160,
            $SlideWidth: 200,
            $SlideSpacing: 3,
            $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$,
                $Steps: 5
            },
            $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$
            }
            };

            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

            /*#region responsive code begin*/

            var MAX_WIDTH = 980;

            function ScaleSlider() {
                var containerElement = jssor_1_slider.$Elmt.parentNode;
                var containerWidth = containerElement.clientWidth;

                if (containerWidth) {

                    var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                    jssor_1_slider.$ScaleWidth(expectedWidth);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }

            ScaleSlider();

            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            /*#endregion responsive code end*/
        };
    </script>
    <style>
        /*jssor slider loading skin spin css*/
        .jssorl-009-spin img {
            animation-name: jssorl-009-spin;
            animation-duration: 1.6s;
            animation-iteration-count: infinite;
            animation-timing-function: linear;
        }

        @keyframes jssorl-009-spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        /*jssor slider bullet skin 057 css*/
        .jssorb057 .i {position:absolute;cursor:pointer;}
        .jssorb057 .i .b {fill:none;stroke:#fff;stroke-width:2000;stroke-miterlimit:10;stroke-opacity:0.4;}
        .jssorb057 .i:hover .b {stroke-opacity:.7;}
        .jssorb057 .iav .b {stroke-opacity: 1;}
        .jssorb057 .i.idn {opacity:.3;}

        /*jssor slider arrow skin 073 css*/
        .jssora073 {display:block;position:absolute;cursor:pointer;}
        .jssora073 .a {fill:#ddd;fill-opacity:.7;stroke:#000;stroke-width:160;stroke-miterlimit:10;stroke-opacity:.7;}
        .jssora073:hover {opacity:.8;}
        .jssora073.jssora073dn {opacity:.4;}
        .jssora073.jssora073ds {opacity:.3;pointer-events:none;}
    </style>
    <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:150px;overflow:hidden;visibility:hidden;">
        <!-- Loading Screen -->
        <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/spin.svg" />
        </div>
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:150px;overflow:hidden;">
            <div>
                <img data-u="image" src="img/001.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/005.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/006.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/007.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/009.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/001.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/005.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/006.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/007.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/009.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/001.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/005.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/006.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/007.jpg" />
            </div>
            <div>
                <img data-u="image" src="img/009.jpg" />
            </div>
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb057" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:16px;height:16px;">
                <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <circle class="b" cx="8000" cy="8000" r="5000"></circle>
                </svg>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora073" style="width:50px;height:50px;top:0px;left:30px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <path class="a" d="M4037.7,8357.3l5891.8,5891.8c100.6,100.6,219.7,150.9,357.3,150.9s256.7-50.3,357.3-150.9 l1318.1-1318.1c100.6-100.6,150.9-219.7,150.9-357.3c0-137.6-50.3-256.7-150.9-357.3L7745.9,8000l4216.4-4216.4 c100.6-100.6,150.9-219.7,150.9-357.3c0-137.6-50.3-256.7-150.9-357.3l-1318.1-1318.1c-100.6-100.6-219.7-150.9-357.3-150.9 s-256.7,50.3-357.3,150.9L4037.7,7642.7c-100.6,100.6-150.9,219.7-150.9,357.3C3886.8,8137.6,3937.1,8256.7,4037.7,8357.3 L4037.7,8357.3z"></path>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora073" style="width:50px;height:50px;top:0px;right:30px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <path class="a" d="M11962.3,8357.3l-5891.8,5891.8c-100.6,100.6-219.7,150.9-357.3,150.9s-256.7-50.3-357.3-150.9 L4037.7,12931c-100.6-100.6-150.9-219.7-150.9-357.3c0-137.6,50.3-256.7,150.9-357.3L8254.1,8000L4037.7,3783.6 c-100.6-100.6-150.9-219.7-150.9-357.3c0-137.6,50.3-256.7,150.9-357.3l1318.1-1318.1c100.6-100.6,219.7-150.9,357.3-150.9 s256.7,50.3,357.3,150.9l5891.8,5891.8c100.6,100.6,150.9,219.7,150.9,357.3C12113.2,8137.6,12062.9,8256.7,11962.3,8357.3 L11962.3,8357.3z"></path>
            </svg>
        </div>
    </div>
    <script type="text/javascript">jssor_1_slider_init();</script>
    </div>
    </div>

</div>

<div class="row">
    <div class="col-md-12">
    <h3>Video</h3>

    <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="video-container">
            <iframe width="100%" height="100%" src="https://www.youtube.com/embed/5CeoxXu9ut8" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="video-container">
            <iframe width="100%" height="100%" src="https://www.youtube.com/embed/I8O91X9epeI" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        </div>
        </div>

        <div class="col-md-3 col-sm-6 hidden-xs">
        <div class="video-container">
            <iframe width="100%" height="100%" src="https://www.youtube.com/embed/YQPoB1UOgC0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        </div>
        </div>

        <div class="col-md-3 col-sm-6 hidden-xs">
        <div class="video-container">
            <iframe width="100%" height="100%" src="https://www.youtube.com/embed/jQ57ZQFClco" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        </div>
        </div>
    </div>
    </div>

</div>
</div>

</div>

</div>