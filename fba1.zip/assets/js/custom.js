/*
Company Name: IT Devs Ltd
Author: IT Devs
Version: 1.0
*/


$(document).ready(function () {

  var top = $('#header').offset().top;

  $(window).scroll(function (event) {
    var y = $(this).scrollTop();
    if (y >= 40){
		$("#header").addClass("fixed-header");
		}
    else
	{
	$("#header").removeClass("fixed-header");
	}


	/**  reading article ****/
	if(y >= 400){

		$('.read-article-headline').addClass("fixed-read-article-headline");
		var widFixedHeadline = $(".read-article-content").width();
		$(".fixed-read-article-headline").width(widFixedHeadline);

		$('.ad-read-art-left-180x400').css("position","absolute");
		$('.ad-read-art-left-180x400').css("top","450px");
		}else{
		$('.read-article-headline').removeClass("fixed-read-article-headline");
		$('.ad-read-art-left-180x400').css("position","fixed");
		$('.ad-read-art-left-180x400').css("top","100px");
			}

	if(y >= 500){

		$('.ad-read-art-left-180x400').css("position","fixed");
		$('.ad-read-art-left-180x400').css("top","10px");
	}

	/*===========   fix facebook widget ===========*/
	if(y >= 560){
		$(".facebook-widget-continer").css("position","fixed");
		$(".facebook-widget-continer").css("top","50px");
		$(".facebook-widget-continer").css("width","285px");
		}else{
		$(".facebook-widget-continer").css("position","relative");
		$(".facebook-widget-continer").css("top","0px");

			}

	/*===================  home auto search =========================*/
	if(y >= 1250 && y < 2200){
		$(".search-more-news-container").css("position","fixed");
		$(".search-more-news-container").css("top","50px");
		$(".search-more-news-container").css("background","#ececec");
		$(".search-more-news-container").css("box-shadow","0px 0px 40px 0px #888");
		$("#row-4-col-2").css("position","fixed");
		$("#row-4-col-2").css("top","60px");
  }else if (y >= 2200) {
    $("#row-4-col-2").css("position","absolute");
    $("#row-4-col-2").css("top","950px");
  }else{
		$(".search-more-news-container").css("position","relative");
		$(".search-more-news-container").css("top","0px");
		$(".search-more-news-container").css("background","#fff");
		$(".search-more-news-container").css("box-shadow","none");
		$("#row-4-col-2").css("position","relative");
		$("#row-4-col-2").css("top","0px");

			}
		 
		 /**  feed **/
	 
	 if(y >= 2670){
		 $(".feed-banner-1").css("position","fixed");
		 $(".feed-banner-1").css("top","120px");
		 $(".feed-banner-1").css("width","210px");
		 
		 $(".top-tags").css("position","fixed");
		 $(".top-tags").css("top","120px");
		 } else{
			 $(".feed-banner-1").css("position","relative");
			 $(".feed-banner-1").css("top","0px");
			 
			 $(".top-tags").css("position","relative");
			 $(".top-tags").css("top","0px");
			 }
  });


  /*===============  live search ====================*/

  $("#search-query").keyup(function(){
	  var search_query = $("#search-query").val();

	  if(search_query.length >= 4){

		  $.post("ajax_search_more_articles.php",
    	{
        shakisha: "yes",
        query: search_query
    	},

    	function(data){

		$("#display-seach-results").load("ajax_search_more_articles.php");

    });
	}

	  });

 $('#subscribe').click(function(){
	var subscriber_name = $("#names").val();
	var subscriber_email = $("#email").val();

	 if(subscriber_name==''){

		 $("#names").css("border-color","#c00");

		 }if(subscriber_email==''){
			 $("#email").css("border-color","#c00");
			 }

			 if(subscriber_name!='' && subscriber_email!='')
			 {
			  $('#subscribe').val("Tegereza gato...");
			  $("#email").val("");
			  $("#names").val("");
			 $.post("php.php",
    	{
        subscribe: "yes",
        names: subscriber_name,
        email: subscriber_email
    	},

    	function(data){
		$('#subscribe').hide();
		$(".form-control-feedback").html("<div class='alert alert-white'>"+data+"</div>");
		location.reload();

    });
	}
	 });
	 
	/// UPDATE VIEWS 
	
	var art_id = $("#article_id").val();
	if(art_id !==''){
		
		var screensize = screen.width;
		if (screensize > 700)
		{
		$.post("update-views.php",
    	{
		update: "yes",
        article_id: art_id
    	},

    	function(data){
	
			});
		}
	}
});
