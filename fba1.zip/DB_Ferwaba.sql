-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 06, 2018 at 11:25 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `DB_Ferwaba`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`id`, `title`, `content`, `date_of_p`) VALUES
(1, 'Itangazo', '<p>orem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid beatae maxime culpa. Blanditiis perferendis fugiat est asperiores aut, eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.</p>\r\n', '2018-11-05 13:01:07'),
(2, 'Announcement 2', '<p>loremipsum igart yupo noi erotiko mouitre&nbsp; loremipsum igart yupo noi erotiko mouitre loremipsum igart yupo noi erotiko mouitre loremipsum igart yupo noi erotiko mouitre loremipsum igart yupo noi erotiko mouitre</p>\r\n', '2018-11-06 11:24:23');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `date_of_event` varchar(50) NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `content`, `date_of_event`, `date_of_p`) VALUES
(7, 'event1', '<p>lorem lorem lolorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem loremlorem</p>\r\n', 'November 22,2018', '2018-11-02 09:41:42'),
(8, 'Event 2', '<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid beatae maxime culpa. Blanditiis perferendis fugiat est asperiores aut, eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit dol</p>\r\n', 'November 30,2018', '2018-11-05 11:50:45'),
(9, 'Event 3', '<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid beatae maxime culpa. Blanditiis perferendis fugiat est asperiores aut, eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.</p>\r\n', 'February 06,2019', '2018-11-05 13:11:23'),
(10, 'Event 4', '<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid beatae maxime culpa. Blanditiis perferendis fugiat est asperiores aut, eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.</p>\r\n', 'December 05,2018', '2018-11-05 13:12:06');

-- --------------------------------------------------------

--
-- Table structure for table `match_update`
--

CREATE TABLE `match_update` (
  `id` int(11) NOT NULL,
  `f_team` varchar(50) NOT NULL,
  `s_team` varchar(50) NOT NULL,
  `f_score` int(11) NOT NULL,
  `s_score` int(11) NOT NULL,
  `approved` int(11) NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `match_update`
--

INSERT INTO `match_update` (`id`, `f_team`, `s_team`, `f_score`, `s_score`, `approved`, `date_of_p`) VALUES
(1, 'Espoir', 'IPRC-Kigali', 26, 30, 0, '2018-11-05 12:08:20'),
(2, 'REG', 'APR_BBC', 76, 81, 0, '2018-11-05 12:53:43'),
(3, 'IPRC-Kigali', 'IPRC-SOUTH', 56, 90, 0, '2018-11-06 12:16:19');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `cover_pic` varchar(200) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `content` text NOT NULL,
  `approved` int(11) NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `cover_pic`, `category`, `content`, `approved`, `date_of_p`) VALUES
(13, 'Title news 1', 'Title news 1.jpg', 'NationalLeague', '<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid beatae maxime culpa. Blanditiis perferendis fugiat est asperiores aut, eligendi dolor<strong> illum ducimus iure</strong> aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid beatae maxime culpa. Blanditiis perferendis fugiat est asperiores aut, eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.</p>\r\n', 0, '2018-11-05 23:07:31'),
(14, 'Title news 2', 'Title news 2.jpg', 'GenocideMemorialTournament', '<p>eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid beatae maxime culpa. Blanditiis perferendis fugiat est asperiores aut, eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.</p>\r\n\r\n<p>&nbsp;</p>\r\n', 0, '2018-11-05 23:08:53'),
(15, 'Title news 3', 'Title news 3.jpg', 'PlayOffs', '<p>eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.</p>\r\n\r\n<p>eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.</p>\r\n\r\n<p>eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.</p>\r\n', 0, '2018-11-05 23:09:30'),
(16, 'Title news 4', 'Title news 4.jpg', 'NationHeroes', '<p>vitae quia odit nam quisquam.eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.eligendi dolor illum ducimus iure aliquam laudantium itaque quo aspernatur. Perferendis libero velit doloremque optio facilis asperiores vitae quia odit nam quisquam.</p>\r\n', 0, '2018-11-05 23:10:21'),
(17, 'titl 7', 'titl 7.jpg', 'NationalLeague', '<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. </p>\r\n', 0, '2018-11-06 12:15:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `match_update`
--
ALTER TABLE `match_update`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `match_update`
--
ALTER TABLE `match_update`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
