-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 10, 2018 at 02:20 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `DB_Ferwaba`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`id`, `title`, `content`, `date_of_p`) VALUES
(4, 'ubutumire mu nteko rusange ya ferwaba', '<p>inteko rusange......................</p>\r\n', '2018-11-09 13:22:53'),
(5, 'amahungurwa y\'abatoza', '<p>AMAHUGURURWA.......</p>\r\n', '2018-11-09 13:23:48'),
(7, 'Impinduka kw\'itangira rya preseassion', '<p>preseason</p>\r\n', '2018-11-09 13:36:51');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `date_of_event` varchar(50) NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `content`, `date_of_event`, `date_of_p`) VALUES
(15, 'Jr NBA tournament', '<p>nba tournament......</p>\r\n', 'September 11,2018', '2018-11-09 13:20:03'),
(16, 'lagacy', '<p>lagacy.....................</p>\r\n', 'October 27,2018', '2018-11-09 13:20:35'),
(18, 'preseason', '<p>preseason......</p>\r\n', 'November 16,2018', '2018-11-09 13:34:37');

-- --------------------------------------------------------

--
-- Table structure for table `match_update`
--

CREATE TABLE `match_update` (
  `id` int(11) NOT NULL,
  `f_team` varchar(50) NOT NULL,
  `s_team` varchar(50) NOT NULL,
  `f_score` int(11) NOT NULL,
  `s_score` int(11) NOT NULL,
  `approved` int(11) NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `match_update`
--

INSERT INTO `match_update` (`id`, `f_team`, `s_team`, `f_score`, `s_score`, `approved`, `date_of_p`) VALUES
(1, 'Espoir', 'IPRC-Kigali', 26, 30, 0, '2018-11-05 12:08:20'),
(2, 'REG', 'APR_BBC', 76, 81, 0, '2018-11-05 12:53:43'),
(3, 'IPRC-Kigali', 'IPRC-SOUTH', 56, 90, 0, '2018-11-06 12:16:19'),
(4, 'Patriots', 'REG', 45, 32, 0, '2018-11-09 12:55:54'),
(5, 'Patriots', 'UGB', 65, 87, 0, '2018-11-09 12:56:04'),
(6, 'IPRC-Kigali', 'REG', 78, 89, 0, '2018-11-09 12:56:29'),
(7, 'APR_BBC', 'REG', 89, 67, 0, '2018-11-09 12:56:44'),
(8, 'IPRC-SOUTH', 'REG', 78, 90, 0, '2018-11-09 12:57:05');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `cover_pic` varchar(200) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `content` text NOT NULL,
  `approved` int(11) NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `match_update`
--
ALTER TABLE `match_update`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `match_update`
--
ALTER TABLE `match_update`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
