-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 10, 2018 at 10:04 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `DB_Ferwaba`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`id`, `title`, `content`, `date_of_p`) VALUES
(4, 'ubutumire mu nteko rusange ya ferwaba', '<p>inteko rusange......................</p>\r\n', '2018-11-09 13:22:53'),
(5, 'amahungurwa y\'abatoza', '<p>AMAHUGURURWA.......</p>\r\n', '2018-11-09 13:23:48'),
(7, 'Impinduka kw\'itangira rya preseassion', '<p>preseason</p>\r\n', '2018-11-09 13:36:51');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `date_of_event` varchar(50) NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `content`, `date_of_event`, `date_of_p`) VALUES
(15, 'Jr NBA tournament', '<p>NBA Tournament......</p>\r\n', 'September 13,2018', '2018-11-09 13:20:03'),
(16, 'lagacy', '<p>lagacy.....................</p>\r\n', 'October 27,2018', '2018-11-09 13:20:35'),
(18, 'preseason', '<p>preseason......</p>\r\n', 'November 16,2018', '2018-11-09 13:34:37');

-- --------------------------------------------------------

--
-- Table structure for table `match_update`
--

CREATE TABLE `match_update` (
  `id` int(11) NOT NULL,
  `f_team` varchar(50) NOT NULL,
  `s_team` varchar(50) NOT NULL,
  `f_score` int(11) NOT NULL,
  `s_score` int(11) NOT NULL,
  `approved` int(11) NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `match_update`
--

INSERT INTO `match_update` (`id`, `f_team`, `s_team`, `f_score`, `s_score`, `approved`, `date_of_p`) VALUES
(1, 'Espoir', 'REG', 28, 30, 0, '2018-11-05 12:08:20'),
(2, 'UGB', 'APR_BBC', 90, 81, 0, '2018-11-05 12:53:43'),
(3, 'IPRC-Kigali', 'IPRC-SOUTH', 56, 90, 0, '2018-11-06 12:16:19'),
(4, 'Patriots', 'REG', 45, 32, 0, '2018-11-09 12:55:54'),
(5, 'Patriots', 'UGB', 65, 87, 0, '2018-11-09 12:56:04'),
(6, 'IPRC-Kigali', 'REG', 78, 89, 0, '2018-11-09 12:56:29'),
(7, 'APR_BBC', 'REG', 89, 67, 0, '2018-11-09 12:56:44'),
(8, 'IPRC-SOUTH', 'REG', 78, 90, 0, '2018-11-09 12:57:05');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `cover_pic` varchar(200) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `content` text NOT NULL,
  `approved` int(11) NOT NULL,
  `date_of_p` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `cover_pic`, `category`, `content`, `approved`, `date_of_p`) VALUES
(1, 'Ferwaba yahuje abakinyi ba IPRC na REG mu gukina ihiganwa kivandimwe', 'Ferwaba yahuje abakinyi ba IPRC na REG mu gukina ihiganwa kivandimwe.jpg', 'NationalLeague', '<p>Nkuko tubikesha ishyirahamwe nyarwanda ry&rsquo;umukino w&rsquo;intoki ariryo FERWABA mu mpine z&rsquo;igifaransa ,magingo aya uko amakipe azacakirana mu gikombe cya &lsquo; PLAY -OFF&rsquo; byamenyekanye ,aho amakipe ane yitwaye neza muri shampiyona yongera kugaragaza ko yari abikwiye. Dore uko gahunda iteye nkuko tubikesha Maboko Didier wo muri federation: *ESPOIR ya mbere(1) izahura na APR &nbsp;ya kane.</p>\r\n\r\n<p>Amakuru mashya agera kandi yizewe &nbsp;aravuga ko byarangije kwemezwa ko umukinnyi mpuzamahanga w&rsquo;umunyarwanda ufite inkomoko mu gihugu cya Congo Kinshasa&nbsp;Kabangu Kami Milambwe, yamaze kubona ikipe nshya mu gihugu cya Morocco yitwa AS FAR (Force Armee Royale) iba mu mujyi wa Rabat.Inganji kuri we no kubanyarwanda cyane cyane abakunda basketball.</p>\r\n', 0, '2018-11-11 23:21:23'),
(2, 'Abakinyi ba KBC na REG bagiye mugihugu c', 'Abakinyi ba KBC na REG bagiye mugihugu c.jpg', 'NationalLeague', '<p>Nkuko tubikesha ishyirahamwe nyarwanda ry&rsquo;umukino w&rsquo;intoki ariryo FERWABA mu mpine z&rsquo;igifaransa ,magingo aya uko amakipe azacakirana mu gikombe cya &lsquo; PLAY -OFF&rsquo; byamenyekanye ,aho amakipe ane yitwaye neza muri shampiyona yongera kugaragaza ko yari abikwiye. Dore uko gahunda iteye nkuko tubikesha Maboko Didier wo muri federation: *ESPOIR ya mbere(1) izahura na APR &nbsp;ya kane.</p>\r\n\r\n<p>Amakuru mashya agera kandi yizewe &nbsp;aravuga ko byarangije kwemezwa ko umukinnyi mpuzamahanga w&rsquo;umunyarwanda ufite inkomoko mu gihugu cya Congo Kinshasa&nbsp;Kabangu Kami Milambwe, yamaze kubona ikipe nshya mu gihugu cya Morocco yitwa AS FAR (Force Armee Royale) iba mu mujyi wa Rabat.Inganji kuri we no kubanyarwanda cyane cyane abakunda basketball.Amakuru mashya agera kandi yizewe &nbsp;aravuga ko byarangije kwemezwa ko umukinnyi mpuzamahanga w&rsquo;umunyarwanda ufite inkomoko mu gihugu cya Congo Kinshasa&nbsp;Kabangu Kami Milambwe, yamaze kubona ikipe nshya mu gihugu cya Morocco yitwa AS FAR (Force Armee Royale) iba mu mujyi wa Rabat.Inganji kuri we no kubanyarwanda cyane cyane abakunda basketball.</p>\r\n', 1, '2018-11-11 23:22:43'),
(3, 'Green Hills Academy na ADEGI Gituza begukanye ibikombe muri shampiyona yatewe inkunga na NBA', 'Green Hills Academy na ADEGI Gituza begukanye ibikombe muri shampiyona yatewe inkunga na NBA.jpg', 'Academy', '<p>Shampiyona y&rsquo;abana batarengeje imyaka 15 yateguwe na FERWABA ku bufatanye na NBA, yegukanywe na Green Hills Academy iyobowe na Sano Rutatika Dick, ugiye kujya gukina muri Leta zunze ubumwe za Amerika.</p>\r\n\r\n<p>hampiyona ya Leta Zunze Ubumwe za Amerika ya Basketball (NBA) ikomeje gushaka impano z&rsquo;abakinnyi b&rsquo;uyu mukino mu bice bitandukanye by&rsquo;Isi, binyuze mu gutangiza shampiyona z&rsquo;abana batarengeje imyaka 15.</p>\r\n\r\n<p>U Rwanda rwabaye igihugu cya 12 muri Afurika NBA itangijemo shampiyona y&rsquo;abato muri uyu mwaka, nyuma ya Cameroun, C&ocirc;te d&rsquo;Ivoire, Nigeria, Kenya, Maroc, Mozambique, Nigeria, S&eacute;n&eacute;gal, Afurikay&rsquo;Epfo, Tanzania na Uganda.</p>\r\n\r\n<p>&nbsp;</p>\r\n', 0, '2018-12-10 10:46:26'),
(4, 'Gatete Djuma yababaje FERWABA yigira umunyamerika', 'Gatete Djuma yababaje FERWABA yigira umunyamerika.jpg', 'NationalLeague', '<p>Umunyarwanda w&rsquo;imyaka 21, Gatete Djuma arabarizwa muri Leta Zunze Ubumwe za Amerika. Ni umukinnyi w&rsquo;umukino wa Basketball akaba akina muri icyo gihugu cya Leta Zunze Ubumwe z&rsquo;Amerika mu ikipe yitwa Long Beach State.</p>\r\n\r\n<p>Iyi kipe ibarizwa muri NCAA. Bimaze kumenyekana ko uno mukinnyi w&rsquo;umunyarwanda ndetse wari urimo kuzamuka neza muri uyu mukino yahinduye ubwenegihugu agafata ubwa Leta Zunze Ubumwe za Amerika kugira ngo azabashe gukinira icyo gihugu mu minsi iri imbere.</p>\r\n\r\n<p>Yari ahagaze neza koko kuko mu minsi ishize yifiuzwaga n&rsquo;ikipe ya Miami Heat ikipe ibarizwa muri NBA. Abakinnyi usanga bakina muri shampiyona ya NBA baba ari ibihangange ku isi kuko gukina muri iyo shampiyona uba uri mu ikipe ikomeye yemererwa gukina muri NBA ifatwa nk&rsquo;icyiciro cya mbere muri Leta Zunze Ubumwe za Amerika.</p>\r\n\r\n<p>Ibi bintu uyu mukinnyi wari umunyarwanda yakoze byababaje Ishyirahamwe Nyarwanda ry&rsquo;umukino wa Basketball ( Ferwaba ). Ababaye, Richard Mutabazi, Umunyamabanga Mukuru w&rsquo;Ishyirahamwe ry&rsquo;Umukino wa Basketball mu Rwanda (Ferwaba ) yavuze ko bamaze kumenya ko Gatete yamaze guhindura ubwenegihugu. Ibi bikaba bishimangira ko adashobora gukinira u Rwanda. Ikibabaje cyane ni uko uno mukinnyi yirengagije ko u Rwanda ari rwo rwamufashije kujya muri Amerika.</p>\r\n\r\n<p>Richard Mutabazi yagize ati &rdquo;byaratubabaje cyane nyuma yo kumenya ko Gatete yahinduye ubwenegihugu kandi ari twe twamufashishije kujya muri Amerika. Uyu musore yari mu bakinnyi b&rsquo;abanyarwanda bakizamuka cyane mu mukino wa Basketball, kuba atazadukinira ni ibintu bibabaje cyane.&rdquo;</p>\r\n\r\n<p>N&rsquo;ubwo ariko ngo Gatete Djuma yirengagije ibyo yakorewe , Richard Mutabazi avuga ko bafite abandi bakinnyi babarizwa muri Leta ya Florida muri Leta Zunze Ubumwe za Amerika na bo bahagaze neza. Abo bakinnyi ngo bakaba babakurikirana kugira ngo nabo batazahindura ubwenegihugu.</p>\r\n\r\n<p>Yagize ati &rdquo;Dufite umukinnyi mwiza witwa Dan Manzi ndetse na Rwabigwi bose bakina muri Leta ya Florida. Dufite kandi Twagirayezu Patrice ukinira i Calfornia na Ngenzi Eric Sambusa ukinira i Washington DC&rdquo;. Akomeza avuga ko abo bose bahagaze neza kandi bakiniye ikipe y&rsquo;igihugu y&rsquo;ingimbi. Ikindi ni uko ngo bakomeje kubakurikirana kugira ngo nabo batazahindura ubwenegihugu ndetse mu minsi iri imbere bakazahamagarwa mu ikipe y&rsquo;igihugu.</p>\r\n\r\n<p>Aba bakinnyi sibo gusa u Rwanda rushaka gukomeza gucungana nabo, ahubwo Umunyamabanga Mukuru wa Ferwaba avuga ko barimo gushaka ubufatanye na za kaminuza zo muri Leta Zunze Ubumwe za Amerika ku buryo bajya boherezayo abakinnyi b&rsquo;Abanyarwanda buri mwaka.</p>\r\n', 0, '2018-12-10 10:47:51'),
(5, 'Ferwaba, Bank of Kigali ink Rwf300m sponsorship deal ', 'Ferwaba, Bank of Kigali ink Rwf300m sponsorship deal .jpg', 'NationalLeague', '<p>Rwanda Basketball Federation (Ferwaba) has landed a Rwf300 million partnership with the Bank of Kigali as the major sponsor of the national basketball league and other major basketball tournaments for the next three years &ndash; till 2021.</p>\r\n\r\n<p>The partnership was signed on Friday afternoon at the headquarters of Bank of Kigali and will start with the upcoming 2018-2019 season.</p>\r\n\r\n<p>Ferwaba president Desire Mugwiza signed on behalf of the local basketball governing body while BK Chief Executive Officer Dr Diane Karusisi signed on behalf of the bank.</p>\r\n\r\n<p>According to Mugwiza, the sponsorship&rsquo;s primary objectives will be to focus on Youth Basketball Development (Junior League for both girls and boys aged under 18) and the national basketball league as well as the post-season Play-off Games.</p>\r\n\r\n<p>Speaking to <em>Saturday Sport </em>on Friday, Mugwiza said: &ldquo;We are happy to start a new partnership with Bank of Kigali, their sponsorship will have a great impact on the development of the sport and the level of our leagues &ndash; starting with the youth competitions.&rdquo;</p>\r\n\r\n<p>&ldquo;The deal is worth Rwf300 million &ndash; Rwf100 million per season.&rdquo;</p>\r\n\r\n<p>Of the annual Rwf100 million installment, 80 per cent will go into technical organisation, while 20 per cent will cater for awards to the best teams and players.</p>\r\n', 0, '2018-12-10 10:49:22'),
(6, 'FERWABA irarambagiza Frank Ntilikina wa NBA ngo yigishe abana Yanditswe na Nsengumukiza Prudence', 'FERWABA irarambagiza Frank Ntilikina wa NBA ngo yigishe abana Yanditswe na Nsengumukiza Prudence.jpg', 'PlayOffs', '<p>Ibyo ni ibyatangajwe n&rsquo;ubuyobozi bw&rsquo;ishyirahamwe ry&rsquo;umukino wa Basketball mu Rwanda (FERWABA) ubwo bwagiranaga ikiganiro n&rsquo;abanyamakuru ku wa gatanu tariki ya 07 Nyakanga 2017.</p>\r\n\r\n<p>Desire Mugwiza, uyobora FERWABA yavuze ko amategeko y&rsquo;Ishyirahamwe ry&rsquo;umukino wa Basketball ku isi (FIBA) ariyo yabaye inzitizi zatumye Frank Ntilikina, umukinnyi wa mbere ufite inkomoko ku Rwanda ugiye gukina muri NBA, adakinira u Rwanda.</p>\r\n\r\n<p>Akomeza avuga ko ariko nubwo atakiniye u Rwanda hari gushakwa uburyo yaza gusura u Rwanda.</p>\r\n\r\n<p>Agira ati &ldquo;Frank Ntilikina tuzamwegera tugirane ibiganiro nawe turebe ko twamuzana mu Rwanda agasura igihugu kuko yatera umurava abandi bana bakina Basketball mu Rwanda.&rdquo;</p>\r\n\r\n<p><img alt=\"JPEG - 116.7Â kb\" src=\"https://www.kigalitoday.com/IMG/jpg/frank-ntilikina-_-rwanda-_-nba-_-france-1.jpg\" /></p>\r\n\r\n<p><strong>Amategeko ya FIBA yazitiye Ntilikina </strong></p>\r\n\r\n<p>Desire Mugwiza avuga ko ariko amategeko ya FIBA yo atandukanye n&rsquo;ay&rsquo;ishyirahamwe ry&rsquo;umupira w&rsquo;amaguru ku isi (FIFA).</p>\r\n\r\n<p>Akomeza avuga ko mu mukino wa Basketball, itegeko riteganya ko iyo umukinnyi yakiniye ikipe y&rsquo;igihugu y&rsquo;abakiri bato y&rsquo;igihugu atuyemo adashobora gukinira ikipe y&rsquo;igihugu akomokamo.</p>\r\n\r\n<p>Umukinnyi Frank Ntilikina nawe yakiniye ikipe y&rsquo;igihugu y&rsquo;u Bufaransa y&rsquo;abakiri bato mu byiciro bitandukanye anegukana igikombe cy&rsquo;Uburayi mu bari munsi y&rsquo;imyaka 18.</p>\r\n\r\n<p><img alt=\"JPEG - 82.8Â kb\" src=\"https://www.kigalitoday.com/IMG/jpg/frank-ntilikina-_-rwanda-_-nba-_-france-4.jpg\" /></p>\r\n\r\n<p><strong>Frank Ntilikina abaye umukinnyi wa mbere ufite inkomoko mu Rwanda ugiye gukina muri NBA</strong></p>\r\n\r\n<p>Mugwiza yasobanuye ko ibyo aribyo byatumye Frank Ntilikina, uherutse kugurwa n&rsquo;ikipe ya New York Knicks, atarashoboye gukinira u Rwanda igihugu ababyeyi be bakomokamo.</p>\r\n\r\n<p>Agira ati &ldquo;Yavukiye mu Bubiligi ajya mu Bufaransa afite imyaka itanu. Ni ukuvuga ngo amategeko ya FIBA uko akora iyo umuntu yakiniye ikipe y&rsquo;igihugu ntabwo yemererwa gukinira ikindi gihugu.</p>\r\n\r\n<p>Ni ukuvuga ngo niba yarakuriye mu Bufaransa bakaza kubona ko afite impano bakamukinisha mu makipe y&rsquo;igihugu y&rsquo;abakiri bato ntakindi gihugu yari kongera gukinira yewe n&rsquo;Ububiligi yavukiyemo ntiyari kubukinira.&rdquo;</p>\r\n', 0, '2018-12-10 10:51:41'),
(7, 'Uko shampiyona ya FERWABA National League 2017-2018 yagenze muri weekend', 'Uko shampiyona ya FERWABA National League 2017-2018 yagenze muri weekend.jpg', 'U18MenNT', '<p><strong>Dore uko imikino yagenze:</strong></p>\r\n\r\n<p><strong>FT- IPRC-KIGALI 95-92 PATRIOTS</strong></p>\r\n\r\n<ul>\r\n	<li><strong>1st QT:&nbsp;</strong>27-22</li>\r\n	<li><strong>2nd QT:</strong>31-18</li>\r\n	<li><strong>3rd QT:</strong>14-20</li>\r\n	<li><strong>4th QT:</strong>23-32</li>\r\n</ul>\r\n\r\n<p><strong>Abakinnyi bakoze amanota menshi:</strong></p>\r\n\r\n<ul>\r\n	<li>Nijimbere Guibert&nbsp;<strong>(IPRC-KIGALI) 28 Points</strong></li>\r\n	<li>HAGUMINTWARI STEVEN&nbsp;<strong>(PATRIOTS) 27 Points</strong></li>\r\n	<li>NDIZEYE DIEU DONNE&nbsp;<strong>(PATRIOTS) 21 Points</strong></li>\r\n	<li>Hitayezu L.<strong>(IPRC-KIGALI) 15 Points</strong></li>\r\n</ul>\r\n\r\n<p><strong>FT &ndash;&nbsp;ESPOIR 91-66 UGB</strong></p>\r\n\r\n<ul>\r\n	<li>1st QT: 13-16</li>\r\n	<li>2nd QT:20-08</li>\r\n	<li>3rd QT:26-17</li>\r\n	<li>4th QT:32-25</li>\r\n</ul>\r\n\r\n<p><strong>Abakinnyi bakoze amanota menshi:</strong></p>\r\n\r\n<ul>\r\n	<li><strong>&nbsp;</strong>NIYONKURU Pascal<strong>&nbsp;(ESPOIR)25 Points</strong></li>\r\n	<li>GATOTO REGIS<strong>(ESPOIR) 20 Points</strong></li>\r\n</ul>\r\n\r\n<p><br />\r\n&nbsp;</p>\r\n\r\n<p><strong>Imikino yo kuwa gatandatu:</strong></p>\r\n\r\n<p><strong>IPRC-SOUTH 58-75 REG</strong></p>\r\n\r\n<ul>\r\n	<li>1st QT: 13-22</li>\r\n	<li>2nd QT:11-18</li>\r\n	<li>3rd QT:17-12</li>\r\n	<li>4th QT:17-23</li>\r\n</ul>\r\n\r\n<p><strong>Abakinnyi bakoze amanota menshi:</strong></p>\r\n\r\n<ul>\r\n	<li>Kami Kabange 32 points</li>\r\n</ul>\r\n\r\n<p><strong>Imikino yo ku cyumweru:</strong></p>\r\n\r\n<p><strong>RUSIZI 51-105 REG</strong></p>\r\n\r\n<ul>\r\n	<li>1st QT:11-30</li>\r\n	<li>2nd QT:14-32</li>\r\n	<li>3rd QT:08-27</li>\r\n	<li>4th QT:18-16</li>\r\n</ul>\r\n\r\n<p><strong>Abakinnyi bakoze amanota menshi:</strong></p>\r\n\r\n<ul>\r\n	<li>Kami Kabange 35 points</li>\r\n	<li>Mukengerwa Benjamin 25 points</li>\r\n</ul>\r\n', 0, '2018-12-10 10:56:12'),
(8, 'BASKETBALL: FERWABA yabonye undi mutera nkunga uzajya atanga miliyoni 100 ku mwaka mu gihe cyâ€™imyaka itatu-AMAFOTO', 'BASKETBALL: FERWABA yabonye undi mutera nkunga uzajya atanga miliyoni 100 ku mwaka mu gihe cyâ€™imyaka itatu-AMAFOTO.jpg', 'NationalLeague', '<p>Ku gica munsi cy&rsquo;uyu wa Gatanu tariki 23 ugushyingo 2018 nibwo ishyirahamwe ry&rsquo;umukino wa Basketball mu Rwanda (FERWABA) ryasinyanye na BK amasezerano y&rsquo;imyaka itatu (3) aho iyi Banki izatanga miliyoni 300 z&rsquo;amafaranga y&rsquo;u Rwanda ariko ikazajya itanga miliyoni 100 buri mwaka.</p>\r\n\r\n<p><a href=\"http://inyarwanda.com/img/201811/logos/1542989259_000a6705.jpg\"><img alt=\"BASKETBALL: FERWABA yabonye undi mutera nkunga uzajya atanga miliyoni 100 ku mwaka mu gihe cyâ€™imyaka itatu-AMAFOTO\" src=\"http://inyarwanda.com/img/201811/logos/1542989259_000a6705.jpg\" /></a></p>\r\n\r\n<p>Muri aya masezerano y&rsquo;imyaka itatu ahwanye na miliyoni 300 z&rsquo;amafaranga y&rsquo;u Rwanda (300,000,000 FRW), FERWABA izajya yakira miliyoni 100 z&rsquo;amafaranga y&rsquo;u Rwanda (100,000,000 FRW) buri mwaka mu gihe cy&rsquo;imyaka itatu (3) ishobora kuzongerwa mu gihe impande zombie zizaba zashimye ubufatanye.</p>\r\n\r\n<p>Aya masezerano azageza mu 2021 arimo ko azaba areba umukino wa Basketball uhereye mu bana bakiri bato kuzamuka kugeza kuri shampiyona, imikino ibanziriza shampiyona yaba mu bahungu n&rsquo;abakobwa.</p>\r\n\r\n<p>Ku bijyanye n&rsquo;imikino y&rsquo;abana, amakipe yitabiriye imikino ya NBA Jr.League 2018 abana bayakinamo bazakomeza guhatana kuko bamaze kurenza imyaka NBA ireba bityo bazashyirirwaho indi shampiyona izaba igerwaho n&rsquo;inkunga y&rsquo;amafaranga yasinyiwe muri aya masezerano.</p>\r\n\r\n<p><img alt=\"Mugwiza Desire perezida wa FERWABA ashyira umukono ku masezerano\" src=\"http://inyarwanda.com/img/201811/attachments/1542989903_000a6698.jpg\" style=\"height:667px; width:1000px\" /></p>\r\n\r\n<p>Mugwiza Desire perezida wa FERWABA ashyira umukono ku masezerano</p>\r\n', 0, '2018-12-10 10:58:41'),
(9, 'Imwe mu myanzuro yafatiwe mu nama yâ€™inteko rusange ya FERWABA', 'Imwe mu myanzuro yafatiwe mu nama yâ€™inteko rusange ya FERWABA.jpg', 'PlayOffs', '<p><strong>Kuri iki Cyumweru taliki ya 22 Ukwakira 2017, nibwo ishyirahamwe ry&rsquo;umukino wa Basketball mu Rwanda FERWABA ryagize inama rusange isanzwe aho ku murongo w&rsquo;ibyigwa harimo gushyiraho I taliki shampiyona izatangiriraho aho henejwe ko izatangira taliki ya 01 Ukuboza 2017.</strong><br />\r\n<img alt=\"\" src=\"http://umuryango.rw/local/cache-vignettes/L860xH574/ferwaba_4-d68aa.jpg?1537745430\" style=\"height:574px; width:860px\" /><br />\r\nNyuma y&rsquo;aho shampiyona y&rsquo;umwaka ushize irangiye ndetse ikegukanwa na REG BBC,kuri ubu abayobozi b&rsquo;amakipe atandukanye bahuriye hamwe n&rsquo;aba FERWABA baganira byinshi mu rwego rwo kunoza uyu mukino mu mwaka wa shampiyona utaha.</p>\r\n\r\n<p><strong>Bimwe mu byaganiriweho muri iyi nama:</strong><br />\r\n1. Raporo y&rsquo;ibikorwa na Championnat 2016/2017<br />\r\n2. Ishusho y&rsquo;umutungo 2016/2017<br />\r\n3. Raporo ya Komite ngenzuzi (Audit)<br />\r\n4. Gahunda y&rsquo;ibikorwa na Championnat 2017/2018<br />\r\n<img alt=\"\" src=\"http://umuryango.rw/local/cache-vignettes/L860xH574/ferwaba_3-eec6f.jpg?1537745430\" style=\"height:574px; width:860px\" /><br />\r\nImwe mu myanzuro y&rsquo;ingenzi yafatiwe muri iyinama ni uko imikino yo gutegura shampiyona izatangira taliki ya 17 kugeza ku ya 26 Ugushyingo 2017 ndetse shampiyona itangira taliki ya 01 Ukuboza uyu mwaka.</p>\r\n\r\n<p>Ku bijyanye n&rsquo;amarushanwa y&rsquo;abakiri bato (Ferwaba Jr league) FERWABA yavuze ko azatangira mu kwezi kwa 12 ndetse n&rsquo;amarushanwa ya NBA Jr League ibyayo bizatangazwa mu minsi iri imbere.</p>\r\n', 0, '2018-12-10 11:01:05'),
(10, 'Patriots crowned basketball league champions ', 'Patriots crowned basketball league champions .jpg', 'PlayOffs', '<p><strong>Friday</strong></p>\r\n\r\n<p>Patriots 57-64 REG</p>\r\n\r\n<p>Powerhouse Patriots were crowned champions of the 2017/2018 Star Times Basketball National League on Friday night, dethroning holders Rwanda Energy Group &ndash; REG.</p>\r\n\r\n<p>Cyril Kalima&rsquo;s REG defeated Patriots in a tightly contested 64-57 victory but it was not enough to help the Electricians side retain the championship.</p>\r\n\r\n<p>Patriots who beat REG 75-60 in the first-leg game last December, won the title courtesy of a better head-to-head ratio this season.</p>\r\n\r\n<p>For REG to reclaim the league title, they needed a victory with scoreline larger than 15 points of difference but Patriots would not let go, fighting so hard to remain unshaken despite the arch-rivals taking control of the game for most of the time, especially in the first three quarters.</p>\r\n\r\n<p>Then reigning champions REG started the game on a flying pace, taking the first quarter 17-12 and the second one 19-14 to into half-time with a promising 36-26 lead.</p>\r\n\r\n<p>Returning for the second half, REG picked it from where they left off, claiming the third quarter 17-13. A two-point margin win in the last quarter was sufficient to see them retaining the league but Aristide Mugabe and teammates turned tables up so quickly when it mattered most, snatching the final quarter, 18-11, in style to narrow the deficit to 64-57.</p>\r\n\r\n<p>Rwanda international Kami Kabange, playing for REG, scored a game high 24 points, star power-forward Olivier Shyaka added 14 while Elie Kaje contributed 10 points respectively.</p>\r\n\r\n<p>Forward Steven Havugintwari topped Patriots&rsquo; scoresheet with 15 points and a game high 10 rebounds whilst guard Sedar Sagamba and Dieudonne Ndizeye posted 13 and 9 points respectively.</p>\r\n\r\n<p>By winning the league title, Patriots booked ticket to represent the country at the 2019 FIBA Africa Zone 5 Club 5 championship.</p>\r\n\r\n<p><strong>Past champions since 2010</strong></p>\r\n\r\n<p>2018 &ndash; Patriots<br />\r\n2017 &ndash; REG<br />\r\n2016 &ndash; Patriots<br />\r\n2015 &ndash; Espoir<br />\r\n2014 &ndash; Espoir<br />\r\n2013 &ndash; Espoir<br />\r\n2012 &ndash; Espoir<br />\r\n2011 &ndash; Kigali Basketball Club<br />\r\n2010 - APR</p>\r\n', 0, '2018-12-10 11:02:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `match_update`
--
ALTER TABLE `match_update`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `match_update`
--
ALTER TABLE `match_update`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
