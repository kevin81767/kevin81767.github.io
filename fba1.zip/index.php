<?php require "templates/header.php";?>
<?php require "pages.php";?>
<?php require "templates/footer.php";?>