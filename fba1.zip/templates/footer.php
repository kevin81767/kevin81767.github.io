<div class="container-fluid">
        <div class="row">
            <div class="footer">
                <div class="wrapper">
                    <div class="container-fluid">

                    <div class="top-footer">
                        <div class="row">

                            <div class="col-md-4 col-lg-4 col-sm-4  col-xs-12 mission">
                                <h2>Our Mission</h2>
                                <p>"Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit porro modi nobis exercitationem dolore in nesciunt, et ratione esse, explicabo neque nostrum."</p>
                            </div>

                            <div class="col-md-4 col-lg-4 col-sm-4  col-xs-12 social-media">
                                <h2>Follow Us On:</h2>
                                <i class="fa fa-facebook fa-2x"></i>
                                <i class="fa fa-twitter fa-2x"></i>
                                <i class="fa fa-linkedin fa-2x"></i>
                                <i class="fa fa-instagram fa-2x"></i>
                            </div>

                            <div class="col-md-4 col-lg-4 col-sm-4  col-xs-12">
                                <h2>Contact Us</h2>
                                <ul>
                                    <li><i style="color:white;" class="fa fa-map"></i> Remera KG45 St</li>
                                    <li><i class="fa fa-phone"></i> +250 784438186</li>
                                    <li><i class="fa fa-envelope"></i> ferwaba@gmail.com</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div class="copyright">
                    <p>Copyright &copy; Ferwaba. All Right reserved.</p>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.timeago.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script type='text/javascript' src='//platform-api.sharethis.com/js/sharethis.js#property=5ae82a56d6704600179d6171&product=inline-share-buttons' async='async'></script>
    <script src="assets/js/jquery.timeago.js"></script>
    <script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery("time.timeago").timeago();
    });
    </script>
    <script src="assets/js/wow.js"></script>
    <script>
    wow = new WOW(
        {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
        console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
        }
    );
    wow.init();
    document.getElementById('moar').onclick = function() {
        var section = document.createElement('section');
        section.className = 'section--purple wow fadeInDown';
        this.parentNode.insertBefore(section, this);
    };
    </script>
    <script type='text/javascript'>
    (function(){ var widget_id = 'PumZD5C4ah';var d=document;var w=window;function l(){
    var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
    </script>
    <!-- {/literal} END JIVOSITE CODE -->
        <!-- JS Script -->
    <script type="text/javascript">
        jQuery(document).ready(function() {
            jQuery("time.timeago").timeago();
        });
        </script>
        <script src="assets/js/wow.js"></script>
        <script>
        wow = new WOW(
        {
            animateClass: 'animated',
            offset:       100,
            callback:     function(box) {
            console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
            }
        }
        );
        wow.init();
        document.getElementById('moar').onclick = function() {
        var section = document.createElement('section');
        section.className = 'section--purple wow fadeInDown';
        this.parentNode.insertBefore(section, this);
        };
    </script>
        <script language="JavaScript">
            $("#event-o").onclick(function(){
            })

        </script>
        <!-- Horizontal - Genius Sports Widget -->
        <script>
        window.spw_920J9U9N18P8RJXLDYF6HMM010LDU7 = {};
        (function(a,b,c,d,e,f){e=b.createElement('script');f=b.getElementsByTagName('script')[0];e.async=1;e.src=c+'/?'+d;f.parentNode.insertBefore(e,f)})(window,document,'https://widget.wh.geniussports.com/widget/','920J9U9N18P8RJXLDYF6HMM010LDU7');
        </script>

</body>
</html>

