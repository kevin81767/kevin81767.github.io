<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Ferwaba</title>
    <META NAME="Title" CONTENT="">
	  <META NAME="Keywords" CONTENT="">
	  <META NAME="Description" CONTENT="">
	  <META NAME="Subject" CONTENT="Amakuru ">
	  <META NAME="Language" CONTENT="kinyarwanda">
	  <meta name='copyright' content='Ferwaba'>
    <meta name="author" content="IT Devs Team">
    <meta name='designer' content='IT Devs Team'>
	  <meta name='reply-to' content='devs@itdevs.rw'>
	  <meta name='owner' content='IT Devs Ltd'>
    <meta property="og:url"           content="" />
  	<meta property="og:type"          content="website" />
  	<meta property="og:title"         content="" />
  	<meta property="og:description"   content="" />
  	<meta property="og:image"         content="" />
  	<meta property="og:author"        content="IT Devs Team" />
    <!-- External CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/main.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700" rel="stylesheet">
    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.png">
    <script src="assets/js/jquery.min.js"></script>
    <style media="screen">
      .results{
        font-size: 20px;
        font-weight: bolder;
      }

      .team{
        padding: 10px;
        height: 30px;
      }

      h2{
        font-size: 18px;
        font-weight: bold;
        padding: 0px;
        margin: 0px;
        color: #d96926;
      }

      .img{
        padding: 10px;
        width: 100px;
      }

      .dropdown-menu li a{
        background: #d96926 !important;
      }

      .announcement{
        margin-top: 5px;
        font-size: 18px;
        border-bottom: solid 1px #888888;
        padding-bottom: 10px;
      }
    </style>

</head>
<body onload="startTime()" onkeypress="return disableCtrlKeyCombination(event);" onkeydown="return disableCtrlKeyCombination(event);">
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.1&appId=206925953176329&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));
</script>

  <div id="header">
    <!-- welcome headline sliding start -->



    <!-- start navigation bar -->
    <nav class="navbar navbar-inverse">
      <div class="navbar-wrapper">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a href="index.php" class="navbar-brand" href="#"><img width=170 src="assets/images/ferwaba-logo-header.png" class="logo-header"></a>
          </div>
          <div class="collapse navbar-collapse" id="navigation">
            <ul class="nav navbar-nav">
              <li class="active"><a href="index.php?p=home"> Home </a></li>
              <li><a href="#" class="dropdown-toggle" data-toggle="dropdown">About Ferwaba</a>
                <ul class="dropdown-menu">
                  <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Organigram/Structure</a>
                    <ul class="dropdown-menu">
                      <li><a href="#">General assembly</a></li>
                      <li><a href="#">Executive commitee</a></li>
                      <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown" >Commissions</a>
                        <ul class="dropdown-menu">
                          <li><a href="#">Technical and Competition</a></li>
                          <li><a href="#">Medical</a></li>
                          <li><a href="#">Legal</a></li>
                          <li><a href="#">Women</a></li>
                          <li><a href="#">Youth Development</a></li>
                          <li><a href="#">Marketing</a></li>
                        </ul>
                      </li>
                      <li><a href="#">Office</a></li>
                      <li><a href="#">Advisors</a></li>
                      <li><a href="#">Auditors</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown" >Coaches</a>
                    <ul class="dropdown-menu">
                      <li><a href="#">Database</a></li>
                      <li><a href="#">How to become a coach?</a></li>
                      <li><a href="#">Training materials</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown" >Officials</a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Database</a></li>
                        <li><a href="#">How to become an official</a></li>
                        <li><a href="#">Training materials</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown" >Documents</a>
                    <ul class="dropdown-menu">
                      <li><a href="#">Reglements generaux des competitions (FERWABA)</a></li>
                      <li><a href="#">FIBA rules and regulations</a></li>
                      <li><a href="#">Reglements d'ordre interieur (FERWABA)</a></li>
                      <li><a href="#">Reports,action plans,strategic plans</a></li>
                    </ul>
                  </li>
                  <li class="dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown" >Clubs</a>
                    <ul class="dropdown-menu">
                      <li><a href="#">Women Club</a></li>
                      <li><a href="#">Men Club</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
              <li><a href="dropdown" class="dropdown-toggle" data-toggle="dropdown">Competitions</a>

                <ul class="dropdown-menu">
                  <li><a href="index.php?p=category&amp;cat=NationalLeague">National League</a></li>
                  <li><a href="index.php?p=category&amp;cat=GenocideMemorialTournament">Genocide memorial tournament</a></li>
                  <li><a href="index.php?p=category&amp;cat=PlayOffs">Playoffs</a></li>
                  <li><a href="index.php?p=category&amp;cat=PreSeasons">Pre-seasons</a></li>
                  <li><a href="NationHeroes">Nation Heroes tournament</a></li>
                  <li><a href="LegacyTournament">Legacy tournament</a></li>
                </ul>

              </li>
              <li><a class="dropdown-toggle" href="#" data-toggle="dropdown">National team</a>
                <ul class="dropdown-menu">
                  <li><a href="index.php?p=category&amp;cat=SeniorMen">Senior men NT</a></li>
                  <li><a href="index.php?p=category&amp;cat=WomenSenior">Women senior NT</a></li>
                  <li><a href="index.php?p=category&amp;cat=U18MenNT">U18 Men NT</a></li>
                  <li><a href="index.php?p=category&amp;cat=U18WomenNT">U18 Women NT</a></li>
                  <li><a href="index.php?p=category&amp;cat=U16BoysNT">U16 Boys NT</a></li>
                  <li><a href="index.php?p=category&amp;cat=U16GirlNT">U16 Girls NT</a></li>
                </ul>
              </li>
              <li><a href="#">3 X 3</a></li>
              <li><a href="#">Live Stats</a></li>
              <li><a class="dropdown-toggle" href="#" data-toggle="dropdown">Development</a>
                <ul class="dropdown-menu">
                  <li><a href="#">Training Camps</a></li>
                  <li><a href="index.php?p=category&amp;cat=Academy">Academy</a></li>
                  <li><a href="index.php?p=category&amp;cat=MiniBasket">Mini-Basketball</a></li>
                </ul>
              </li>
              <li><a href="#">Contact</a></li>
              <form class="navbar-form navbar-left">
                <div class="input-group has-search">
                  <input type="text" class="form-control input-sm" placeholder="Search">
                  <div class="input-group-btn">
                    <button class="btn btn-default btn-sm" type="submit">
                      <i style="color:orange;" class="fa fa-search"></i>
                    </button>
                  </div>
                </div>
              </form>
            </ul>
          </div>
        </div>
      </div>
    </nav>
    <!-- end wrapper--->
    </nav>
    <!-- end navigation--->
    </div>
    <!-- end header -->

    <!-- end mobile-->