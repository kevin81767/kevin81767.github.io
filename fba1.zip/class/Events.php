<?php
Class Events extends Database{
    // Events

    public function retrieveEvents(){

        $req=$this->getPDO()->query("SELECT * FROM events LIMIT 3");
        $rep=$req->fetchAll();
        return $rep;
    }

}