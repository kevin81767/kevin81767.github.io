<?php
Class Events extends Database{
    // Events

    public function retrieveEvents(){

        $req=$this->getPDO()->query("SELECT * FROM events LIMIT 3");
        $rep=$req->fetchAll();
        return $rep;
    }

    // retrieve event for one
    public function eventBy_Id($id){
        $req=$this->getPDO()->prepare("SELECT * FROM events WHERE id=?");
        $req->execute(array($id));
        $res=$req->fetchAll(PDO::FETCH_OBJ);
        return $res;
    }

}