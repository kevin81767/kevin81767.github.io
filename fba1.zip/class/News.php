<?php
Class News extends Database{
    // News

    public function retrieveNews(){

        $req=$this->getPDO()->query("SELECT * FROM news LIMIT 5");
        $rep=$req->fetchAll();
        return $rep;
    }

    // retrieve news for one
    public function newsBy_Id($id){
        $req=$this->getPDO()->prepare("SELECT * FROM news WHERE id=?");
        $req->execute(array($id));
        $res=$req->fetchAll(PDO::FETCH_OBJ);
        return $res;
    }

    // retrieve news and category
    public function newsBy_Cat($cat){
        $req=$this->getPDO()->prepare("SELECT * FROM news WHERE category=?");
        $req->execute(array($cat));
        $res=$req->fetchAll(PDO::FETCH_OBJ);
        return $res;
    }

}