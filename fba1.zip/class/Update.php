<?php
Class Update extends Database{
    // Events

    public function retrieveMatch(){

        $req=$this->getPDO()->query("SELECT * FROM match_update LIMIT 4");
        $rep=$req->fetchAll();
        return $rep;
    }

}