<?php

Class Announcements extends Database{
    // Announcement

    public function retrieveAnnounces(){

        $req=$this->getPDO()->query("SELECT * FROM announcement ORDER BY id DESC");
        $rep=$req->fetchAll();
        return $rep;
    }

    // retrieve Announcement for one
    public function annBy_Id($id){
        $req=$this->getPDO()->prepare("SELECT * FROM announcement WHERE id=?");
        $req->execute(array($id));
        $res=$req->fetchAll(PDO::FETCH_OBJ);
        return $res;
    }

}