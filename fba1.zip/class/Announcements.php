<?php

Class Announcements extends Database{
    // Announcement

    public function retrieveAnnounces(){

        $req=$this->getPDO()->query("SELECT * FROM announcement");
        $rep=$req->fetchAll();
        return $rep;
    }

}