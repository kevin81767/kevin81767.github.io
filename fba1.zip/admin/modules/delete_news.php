<?php
if(isset($_GET['id'])){
    $id=$_GET['id'];
    require '../class/Database.php';
    require '../class/News.php';

    $datas=New News();
    $res=$datas->delete_News($id);
    if($res){

        ?>
        <div class="alert alert-success">
            <h3>The Post has been deleted</h3>
        </div>
        <a href="../browse.php"><button class="btn btn-info">Back to News Page</button></a>
        <?php
    }

}