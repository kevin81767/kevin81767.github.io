<?php
if(isset($_POST['f_team']) AND isset($_POST['s_team']) AND isset($_POST['f_score']) AND isset($_POST['s_score'])){

    $f_team=$_POST['f_team'];
    $s_team=$_POST['s_team'];
    $f_score=$_POST['f_score'];
    $s_score=$_POST['s_score'];
    $approved=0;
    $res=New Update();
    $data=$res->update_Match($f_team,$s_team,$f_score,$s_score,$approved);
    if($data){
        ?>
        <div class="alert alert-success">
            <i class="fa fa-thumbs-up"></i> Match updated Successfully!!
        </div>
        <?php
    }
    else{
        echo "ERROR. Retry";
    }
}