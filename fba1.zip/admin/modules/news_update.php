<?php
if(!empty($_POST['title']) AND ($_POST['editor']) AND ($_POST['category']) )
{
        $title=$_POST['title'];
        $content=$_POST['editor'];
        $category=$_POST['category'];
        $approved=1;
        //sending the cover picture
        if (isset($_FILES['pictures']) AND ($_FILES['pictures']['error'])==0)
    {
        $maxsize=1000000000000;
        $path='../modules/covers/';
        $extensions=array('.jpg','.jpeg','.png','.gif');
        $extension=strrchr($_FILES['pictures']['name'],'.');
        $namepic=$title;
        if (!in_array($extension, $extensions))
        {
            $error= "Error: The extension of the picture is not allowed";
        }

        if ($_FILES['pictures']['size'] > $maxsize)
        {
            $error="Size too big";
        }

        if(!isset($error))
        {
            $picture_cover=str_replace($_FILES['pictures']['tmp_name'],'',$namepic).$extension;
            if(move_uploaded_file($_FILES['pictures']['tmp_name'], $path.$picture_cover))
            {
                $res=New News();
                $data=$res->update_News($id,$title,$picture_cover,$category,$content,$approved);
                if($data){
                    ?>
                        <div class="alert alert-success">
                            Uploaded successfully!!
                        </div>
                    <?php
                }
            }
        }
        else
        {
            echo $error;
        }
    }
}