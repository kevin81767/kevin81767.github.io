<?php
if(!empty($_POST['title']) AND ($_POST['editor']) AND ($_POST['date_event']) )
{
        $title=$_POST['title'];
        $content=$_POST['editor'];
        $date_of_event=$_POST['date_event'];
        //sending the cover picture
        $res=New Events();
        $data=$res->upload_Events($title,$content,$date_of_event);
        if($data){
            ?>
                <div class="alert alert-success">
                    <i class="fa fa-thumbs-up"></i> Uploaded successfully!!
                </div>
            <?php
        }
}