<?php
if(isset($_POST['editor'])){
    $announce=$_POST['editor'];
    $title=$_POST['title'];
    $res=New Announcements();
    $data=$res->upload_Announces($title,$announce);
    if($data){
        ?>
            <div class="alert alert-success">
                <i class="fa fa-thumbs-up"></i> Uploaded successfully!!
            </div>
        <?php
    }
}