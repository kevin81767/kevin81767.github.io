<div class="alert alert-danger">
    <h3 style="text-align:center;"> <i class="fa fa-warning"></i> The page you are requesting does not exist</h3>
</div>