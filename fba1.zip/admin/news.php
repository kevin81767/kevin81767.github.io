<!-- Modal -->
<?php
    require "class/Database.php";
    require "class/News.php";
    require 'modules/news_upload.php';
?>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add News</h4>
            </div>
            <div class="modal-body">
                <form action="#" method="POST" class="form-group" enctype="multipart/form-data">
                    <input type="text" name="title" placeholder="Title of the post" class="form-control input-lg">
                    <br>
                    <label for="">Upload a cover picture</label>:<input type="file" name="pictures" id="pictures">
                    <div id="selectedFiles"></div>
                    <br>
                    <label for="">Category</label>:
                    <select name="category" class="form-control" id="">
                        <option value="NationalLeague">National League</option>
                        <option value="GenocideMemorialTournament">Genocide Memorial Tournament</option>
                        <option value="PlayOffs">Play Offs</option>
                        <option value="PreSeasons">PreaSeasons</option>
                        <option value="NationHeroes">National Heroes Tournament</option>
                        <option value="LegacyTournament">Legacy Tournament</option>
                        <option value="SeniorMen">Senior Men NT</option>
                        <option value="WomenSenior">Senior Women NT</option>
                        <option value="U18MenNT">U18 Men NT</option>
                        <option value="U18WomenNT">U18 Women NT</option>
                        <option value="U16BoysNT">U16 Boys NT</option>
                        <option value="U16GirlNT">U16 Girls NT</option>
                        <option value="Academy">Academy</option>
                        <option value="MiniBasket">Mini Basket</option>
                    </select>
                    <br>
                    <br>
                    <textarea name="editor" class="ckeditor"></textarea>
                    <button type="submit" class="btn btn-info btn-block">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="panel panel-default">
    <div class="panel-heading" id="dash-title">
        <div class="panel-title">
            <i class="fa fa-newspaper-o"></i> News
        </div>
    </div>
    <div class="panel-content">
        <button class="btn btn-default btn-md" data-toggle="modal" data-target="#myModal">Add News</button>
        <br>
        <br>
        <?php
        $datas=New News();
        $result=$datas->retrieveNews();
        if($result){
            foreach ($result as $res) {
                ?>
                <div class="box">
                    <a href="#"><h2><?=$res['title'];?></h2></a>
                    <br>
                    <div class="content">
                        <?=$res['content'];?>
                    </div>
                    <em><?=$res['date_of_p'];?></em>
                </div>
                <?php
            }
        }
        ?>
    </div>
</div>