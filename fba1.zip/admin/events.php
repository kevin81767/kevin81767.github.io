<?php
    require "class/Database.php";
    require "class/Events.php";
    require 'modules/events_upload.php';
?>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add Event</h4>
            </div>
            <div class="modal-body">
                <form action="#" method="POST" class="form-inline" enctype="multipart/form-data">
                    <div class="form-group">
                        <input type="text" name="title" placeholder="Name of the event" class="form-control">
                        <input type="text" class="form-control" name="date_event" id="date_match" placeholder="On" required >
                    </div>
                    <br>
                    <textarea name="editor" class="ckeditor"></textarea>
                    <button type="submit" class="btn btn-info btn-block">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="panel panel-default">
    <div class="panel-heading" id="dash-title">
        <div class="panel-title">
            <i class="fa fa-list-alt"></i> Events
        </div>
    </div>
    <div class="panel-content">
        <button class="btn btn-default btn-md" data-toggle="modal" data-target="#myModal">Add an event</button>
        <br>
        <br>
    </div>

    <div class="event">
        <?php
        $datas=New Events();
        $result=$datas->retrieveEvents();
        if($result){
            foreach ($result as $resu) {
                ?>
                <div class="box-event">
                    <h3><?=$resu['title'];?></h3>
                    <div class="content-event"><?=$resu['content'];?></div>
                    <p id="date"><em><?=$resu['date_of_event'];?></em></p>
                    <?php
                    if($_SESSION['admin']['level']=="Administrator"){
                        ?>
                        <br>
                        <br>
                        <button class="btn btn-info btn-md" data-toggle="modal" data-target="#myModal1"><i class="fa fa-check"></i>Approve</button>
                        <button type="button" class="btn btn-warning btn-md dropdown-toggle" data-toggle="dropdown">
                        Action <span class="caret"></span></button>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="browse.php?p=edit_e&amp;id=<?=$resu['id'];?>"><i class="fa fa-pencil"></i> Edit</a></li>
                            <li><a href="modules/delete_event.php?id=<?=$resu['id'];?>"><i class="fa fa-trash"></i> Delete</a></li>
                        </ul>
                        <?php
                    }
                    ?>
                </div>
                <br>
                <br>
                <br>
                <br>
                <?php
            }
        }
        ?>
    </div>
</div>