<?php
require "class/Database.php";
require "class/Update.php";
require "modules/update_match.php";

?>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-xs">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add Match</h4>
            </div>
            <div class="modal-body">
                <form action="#" method="POST" class="form-inline">
                    <div class="form-group">
                        <select name="f_team" class="form-control">
                            <option value="Espoir">Espoir</option>
                            <option value="Patriots">Patriots</option>
                            <option value="IPRC-Kigali">IPRC-Kigali</option>
                            <option value="REG">REG</option>
                            <option value="IPRC-SOUTH">IPRC-SOUTH</option>
                            <option value="UGB">UGB</option>
                            <option value="APR_BBC">APR BBC</option>
                        </select>
                        VS
                        <select name="s_team" class="form-control">
                            <option value="Espoir">Espoir</option>
                            <option value="Patriots">Patriots</option>
                            <option value="IPRC-Kigali">IPRC-Kigali</option>
                            <option value="REG">REG</option>
                            <option value="IPRC-SOUTH">IPRC-SOUTH</option>
                            <option value="UGB">UGB</option>
                            <option value="APR_BBC">APR BBC</option>
                        </select>
                    </div>
                    <h3>Score</h3>
                    <div class="form-group">
                        <input type="number" class="form-control" placeholder="Score" name="f_score">
                        <input type="number" class="form-control" placeholder="Score" name="s_score">
                    </div>
                    <br>
                    <br>
                    <button type="submit" class="btn btn-info btn-md">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="panel panel-default">
    <div class="panel-heading" id="dash-title">
        <div class="panel-title">
            <i class="fa fa-spinner"></i> Match Update
        </div>
    </div>
    <div class="panel-content">
        <button class="btn btn-default btn-md" data-toggle="modal" data-target="#myModal">Add a Match</button>
        <br>
        <br>
        <?php
        $datas=New Update();
        $result=$datas->retrieveMatchUpdate();
        if($result){
            foreach ($result as $res) {
                ?>
                <div class="box">
                    <div class="row">
                        <div class="col-lg-5">
                            <h2 style="text-align:center;"><?=$res['f_team'];?> <span style="border-radius:4px;background-color:#333;color:white;"><?=$res['f_score'];?></span></h2>
                        </div>
                        <div class="col-lg-2">
                            <h1>.VS.</h1>
                        </div>
                        <div class="col-lg-5">
                            <h2 style="text-align:center;"><span style="border-radius:4px;background-color:#333;color:white;"><?=$res['s_score'];?></span> <?=$res['s_team'];?></h2>
                        </div>
                    </div>
                    <?php
                    if($_SESSION['admin']['level']=="Administrator"){
                        ?>
                        <br>
                        <br>
                        <button class="btn btn-info btn-md" data-toggle="modal" data-target="#myModal1"><i class="fa fa-check"></i>Approve</button>
                        <button type="button" class="btn btn-warning btn-md dropdown-toggle" data-toggle="dropdown">
                        Action <span class="caret"></span></button>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="browse.php?p=edit_match&amp;id=<?=$res['id'];?>"><i class="fa fa-pencil"></i> Edit</a></li>
                            <li><a href="modules/delete_match.php?id=<?=$res['id'];?>"><i class="fa fa-trash"></i> Delete</a></li>
                        </ul>
                        <?php
                    }
                    ?>
                </div>
                <br>
                <br>
                <?php
            }
        }
        ?>
    </div>
</div>