<?php
require "class/Database.php";
require "class/Update.php";
require "modules/update_match.php";




?>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-xs">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add Match</h4>
            </div>
            <div class="modal-body">
                <form action="#" method="POST" class="form-inline">
                    <div class="form-group">
                        <select name="f_team" class="form-control">
                            <option value="Espoir">Espoir</option>
                            <option value="Patriots">Patriots</option>
                            <option value="IPRC-Kigali">IPRC-Kigali</option>
                            <option value="REG">REG</option>
                            <option value="IPRC-SOUTH">IPRC-SOUTH</option>
                            <option value="UGB">UGB</option>
                            <option value="APR_BBC">APR BBC</option>
                        </select>
                        VS
                        <select name="s_team" class="form-control">
                            <option value="Espoir">Espoir</option>
                            <option value="Patriots">Patriots</option>
                            <option value="IPRC-Kigali">IPRC-Kigali</option>
                            <option value="REG">REG</option>
                            <option value="IPRC-SOUTH">IPRC-SOUTH</option>
                            <option value="UGB">UGB</option>
                            <option value="APR_BBC">APR BBC</option>
                        </select>
                    </div>
                    <h3>Score</h3>
                    <div class="form-group">
                        <input type="number" class="form-control" placeholder="Score" name="f_score">
                        <input type="number" class="form-control" placeholder="Score" name="s_score">
                    </div>
                    <br>
                    <br>
                    <button type="submit" class="btn btn-info btn-md">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="panel panel-default">
    <div class="panel-heading" id="dash-title">
        <div class="panel-title">
            <i class="fa fa-spinner"></i> Match Update
        </div>
    </div>
    <div class="panel-content">
        <button class="btn btn-default btn-md" data-toggle="modal" data-target="#myModal">Add a Match</button>
        <br>
        <br>
    </div>
</div>