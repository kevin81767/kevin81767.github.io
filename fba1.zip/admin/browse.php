<?php
require "templates/header.php";
require "pages.php";
require "templates/footer.php";
?>