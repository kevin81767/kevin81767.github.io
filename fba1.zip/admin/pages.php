<?php
if(isset($_GET['p'])){
    if($_GET['p']=='news'){
        require "news.php";
    }
    elseif($_GET['p']=="updates"){
        require "update.php";
    }
    elseif($_GET['p']=="announcement"){
        require "announcement.php";
    }
    elseif($_GET['p']=="events"){
        require "events.php";
    }
    else{
        require "404.php";
    }
}
else{
    require "news.php";
}
