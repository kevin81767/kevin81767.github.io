<?php
Class Update extends Database{
    // Announcement
    public function update_Match($f_team,$s_team,$f_score,$s_score,$approved)
    {
        $req=$this->getPDO()->prepare("INSERT INTO match_update (`f_team`, `s_team`, `f_score`, `s_score`, `approved`, `date_of_p`)
			VALUES (?,?,?,?,?,NOW())");
		$req->execute(array($f_team,$s_team,$f_score,$s_score,$approved));
		return $req;
    }

    public function retrieveMatchUpdate(){

        $req=$this->getPDO()->query("SELECT * FROM match_update");
        $rep=$req->fetchAll();
        return $rep;
    }

}