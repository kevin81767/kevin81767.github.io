<?php
Class News extends Database{
    // News
    public function upload_News($title,$picture_cover,$category,$content,$approved)
    {
        $req=$this->getPDO()->prepare("INSERT INTO news (`title`, `cover_pic`,`category`, `content`, `approved`, `date_of_p`)
			VALUES (?,?,?,?,?,NOW())");
		$req->execute(array($title,$picture_cover,$category,$content,$approved));
		return $req;
    }

    // retrieve news for one
    public function newsBy_Id($id){
        $req=$this->getPDO()->prepare("SELECT * FROM news WHERE id=?");
        $req->execute(array($id));
        $res=$req->fetchAll(PDO::FETCH_OBJ);
        return $res;
    }

    // update post
    public function update_News($id,$title,$picture_cover,$category,$content,$approved)
    {
        $req=$this->getPDO()->prepare("UPDATE news set title=?, cover_pic=? ,category=?,content=?,approved=? WHERE id=$id");
		$req->execute(array($title,$picture_cover,$category,$content,$approved));
		return $req;
    }

    public function retrieveNews(){

        $req=$this->getPDO()->query("SELECT * FROM news");
        $rep=$req->fetchAll();
        return $rep;
    }

    public function delete_News($id){

        $req=$this->getPDO()->prepare("DELETE FROM news WHERE id=?");
        $req->execute(array($id));
		return $req;
    }

}