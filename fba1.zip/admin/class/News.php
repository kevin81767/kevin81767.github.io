<?php
Class News extends Database{
    // News
    public function upload_News($title,$picture_cover,$category,$content,$approved)
    {
        $req=$this->getPDO()->prepare("INSERT INTO news (`title`, `cover_pic`,`category`, `content`, `approved`, `date_of_p`)
			VALUES (?,?,?,?,?,NOW())");
		$req->execute(array($title,$picture_cover,$category,$content,$approved));
		return $req;
    }

    public function retrieveNews(){

        $req=$this->getPDO()->query("SELECT * FROM news");
        $rep=$req->fetchAll();
        return $rep;
    }

}