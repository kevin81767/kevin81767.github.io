<?php
Class Events extends Database{
    // News
    public function upload_Events($title,$content,$date_of_event)
    {
        $req=$this->getPDO()->prepare("INSERT INTO events (`title`, `content`, `date_of_event`, `date_of_p`)
			VALUES (?,?,?,NOW())");
		$req->execute(array($title,$content,$date_of_event));
		return $req;
    }

    // Retrieve event
    public function retrieveEvents(){

        $req=$this->getPDO()->query("SELECT * FROM events");
        $rep=$req->fetchAll();
        return $rep;
    }

    // Update event
    public function update_Events($id,$title,$content,$date_of_event)
    {
        $req=$this->getPDO()->prepare("UPDATE events set title=?,content=?,date_of_event=? WHERE id=$id");
		$req->execute(array($title,$content,$date_of_event));
		return $req;
    }


    // retrieve event for one
    public function eventBy_Id($id){
        $req=$this->getPDO()->prepare("SELECT * FROM events WHERE id=?");
        $req->execute(array($id));
        $res=$req->fetchAll(PDO::FETCH_OBJ);
        return $res;
    }

}