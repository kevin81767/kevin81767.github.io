<?php
Class Events extends Database{
    // News
    public function upload_Events($title,$content,$date_of_event)
    {
        $req=$this->getPDO()->prepare("INSERT INTO events (`title`, `content`, `date_of_event`, `date_of_p`)
			VALUES (?,?,?,NOW())");
		$req->execute(array($title,$content,$date_of_event));
		return $req;
    }

    public function retrieveEvents(){

        $req=$this->getPDO()->query("SELECT * FROM events");
        $rep=$req->fetchAll();
        return $rep;
    }

}