<?php
Class Announcements extends Database{
    // Announcement
    public function upload_Announces($title,$content)
    {
        $req=$this->getPDO()->prepare("INSERT INTO announcement ( `title`,`content`, `date_of_p`)
			VALUES (?,?,NOW())");
		$req->execute(array($title,$content));
		return $req;
    }

    public function retrieveAnnounces(){

        $req=$this->getPDO()->query("SELECT * FROM announcement");
        $rep=$req->fetchAll();
        return $rep;
    }

}