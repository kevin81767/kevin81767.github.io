<?php
require "class/Database.php";
require "class/Announcements.php";
require 'modules/ann_upload.php';

?>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add an Announcement</h4>
            </div>
            <div class="modal-body">
                <form action="#" method="POST" class="form-inline" enctype="multipart/form-data">
                    <label for="">Title</label>:
                    <input type="text" name="title" class="form-control input-md">
                    <br>
                    <br>
                    <label for="">Content</label>:
                    <textarea name="editor" class="ckeditor"></textarea>
                    <button type="submit" class="btn btn-info btn-block">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="panel panel-default">
    <div class="panel-heading" id="dash-title">
        <div class="panel-title">
            <i class="fa fa-exclamation-circle"></i> Announcement
        </div>
    </div>
    <div class="panel-content">
        <button class="btn btn-default btn-md" data-toggle="modal" data-target="#myModal">Add an Announcement</button>
        <br>
        <br>
    </div>
    <br>
    <br>
    <?php
    $datas=New Announcements();
    $resu=$datas->retrieveAnnounces();
    if($resu){
        foreach ($resu as $res) {
            ?>
            <div class="alert alert-info">
                <p><i class="fa fa-exclamation-triangle"></i> <?=$res['content'];?> </p>
            </div>
            <?php
        }
    }
    ?>
</div>