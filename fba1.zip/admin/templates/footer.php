    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="ckeditor/ckeditor.js"></script>
    <script>
        $(document).ready(function(){
            // $(".box-overview").hide();
            // $(".panel-heading").click(function(){
            //     $(".box-overview").toggle(500);
            // });

            // Toggle class add house
            $(".form-house").hide();
            $("#add_house_plan").click(function(){
                $(".form-house").toggle(700);
            })
        })
    </script>
    <script>
    $("#date_match").datepicker({
        changeMonth:true,
        changeYear:true,
        dateFormat:"MM dd,yy",
        numberofMonths:1,
        maxDate:365,
        minDate: -3650
    });
        // images preview
        $(function () {
            $("#pictures").change(function () {
                if (typeof (FileReader) != "undefined") {
                    var dvPreview = $("#selectedFiles");
                    dvPreview.html("");
                    var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                    $($(this)[0].files).each(function () {
                        var file = $(this);
                        if (regex.test(file[0].name.toLowerCase())) {
                            var reader = new FileReader();
                            reader.onload = function (e) {
                                var img = $("<img />");
                                img.attr("style", "height:100px;width: 100px;margin:5px");
                                img.attr("src", e.target.result);
                                img.addClass("img_upload");
                                dvPreview.append(img);
                            }
                            reader.readAsDataURL(file[0]);
                        } else {
                            alert(file[0].name + " is not a valid image file.");
                            dvPreview.html("");
                            return false;
                        }
                    });
                } else {
                    alert("This browser does not support HTML5 FileReader.");
                }
            });
        });
    </script>
</body>
</html>