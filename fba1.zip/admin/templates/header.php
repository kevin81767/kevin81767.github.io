<?php
session_start();
// session_destroy();
if(!isset($_SESSION['admin'])){
    header("Location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ferwaba | Dashboard</title>
    <link rel="stylesheet" href="css/main_d.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/jquery-ui.min.css">
</head>
<body>
    <!-- Navbar -->
    <nav>
        <div class='navbar navbar-inverse'>
            <div class='container'>
            <a href='index.php' class='navbar-brand'>Ferwaba</a>
            <button class='navbar-toggle' id='bar' data-toggle='collapse' data-target='.navHeaderCollapse'>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div class='collapse navbar-collapse navHeaderCollapse navb'>
                <ul class='nav navbar-nav navbar-right animated bounceInUp'>
                <li><a href='#'>Welcome, Admin</a></li>
                <li><a href='modules/signOut.php'>Signout</a></li>
                </ul>
            </div>
            </div>
        </div>
    </nav>
    <!-- Jumbotron -->
    <div class="container">
        <div class="well" id="dash-title">
            <h3><i class="fa fa-cog"></i> Dashboard</h3>
        </div>
    <!-- list group -->
        <div class="row">
            <div class="col-lg-3">
                <a id="dash-title" class="list-group-item"><i class="fa fa-cog"></i> Dashboard</a>
                <a href="browse.php?p=news" class="list-group-item"><i class="fa fa-newspaper-o" style="color:#d96926;"></i> News</a>
                <a href="browse.php?p=updates" class="list-group-item"><i class="fa fa-spinner" style="color:#d96926;"></i> Match Updates</a>
                <a href="browse.php?p=events" class="list-group-item"><i class="fa fa-list-alt" style="color:#d96926;"></i> Events</a>
                <a href="browse.php?p=announcement" class="list-group-item"><i class="fa fa-exclamation-circle" style="color:#d96926;"></i> Announcements</a>

            </div>
            <div class="col-lg-9">
                <div class="panel panel-default">
                    <div class="panel-heading" id="dash-title">
                        <h3 class="panel-title">Overview <i class="fa fa-arrow-circle-down"></i></h3>
                    </div>
                    <div class="box-overview">
                        <div class="well">
                            <span><i class="fa fa-newspaper-o fa-2x" style="color:#d96926;"></i></span><h4>News</h4>
                        </div>
                        <div class="well">
                            <span><i class="fa fa-list-alt fa-2x" style="color:#d96926;"></i></span><h4>Events</h4>
                        </div>
                        <div class="well">
                            <span><i class="fa fa-exclamation-circle fa-2x" style="color:#d96926;"></i></span><h4>Announcement</h4>
                        </div>
                    </div>
                </div>
                <br>
