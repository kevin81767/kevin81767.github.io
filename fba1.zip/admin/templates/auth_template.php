<?php
session_start();
if(isset($_SESSION['admin'])){
    header('Location:browse.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shalem | Dashboard</title>
    <link rel="stylesheet" href="css/main_d.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="container">
        <div class="alert alert-info">
            <p style="text-align:center;">Ferwaba Admin Panel</p>
        </div>






        <?=$content;?>
    </div>





    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>