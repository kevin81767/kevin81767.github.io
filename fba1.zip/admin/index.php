<?php

if(isset($_GET['p'])){
    if($_GET['p']=='auth'){
        require 'auth.php';
    }
    else{
        require '404.php';
    }
}
else{
    require 'auth.php';
}

$content=ob_get_clean();
require 'templates/auth_template.php';