
<div class="form-login">
    <?php

    if(isset($_POST['username']) AND isset($_POST['password'])){
        if($_POST['username']=="FerwabaAdmin" AND $_POST['password']=="password"){
            session_start();
            $_SESSION['admin']=array(
                "level"=>"Administrator"
            );

            header("Location:browse.php");
        }
        elseif($_POST['username']=="FerwabaEditor" AND $_POST['password']=="ferwaba1234"){
            session_start();
            $_SESSION['admin']=array(
                "level"=>"Editor"
            );

            header("Location:browse.php");
        }
        else{
            ?>
            <div class="error-login">
                <p> <i class="fa fa-warning"></i> Username or Password incorrect.</p>
            </div>
        <?php
        }

    }


    ?>
    <p><img src="img/logo2.png" alt="" width="100" height="100"></p>
    <div class="alert alert-warning"><p> <i class="fa fa-warning"></i> This Form is allowed to use by the administrator. </p></div>
    <form action="#" method="POST">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" class="form-control">
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" class="form-control">
        </div>
        <button class="btn btn-info btn-block">Submit</button>
    </form>
</div>
