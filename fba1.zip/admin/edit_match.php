<?php
if(isset($_SESSION['admin'])){
    if($_SESSION['admin']['level']=="Administrator"){
        if(isset($_GET['id'])){

            require "class/Database.php";
            require "class/Update.php";

            $id=$_GET['id'];
            $datas=New Update();
            $res=$datas->MatchBy_Id($id);
            if($res){
                require 'modules/edit_match.php';
                ?>
                <form action="#" method="POST" class="form-inline">
                    <div class="form-group">
                        <select name="f_team" class="form-control" value="<?=$res[0]->f_team;?>">
                            <option value="Espoir">Espoir</option>
                            <option value="Patriots">Patriots</option>
                            <option value="IPRC-Kigali">IPRC-Kigali</option>
                            <option value="REG">REG</option>
                            <option value="IPRC-SOUTH">IPRC-SOUTH</option>
                            <option value="UGB">UGB</option>
                            <option value="APR_BBC">APR BBC</option>
                        </select>
                        VS
                        <select name="s_team" class="form-control" value="<?=$res[0]->s_team;?>">
                            <option value="Espoir">Espoir</option>
                            <option value="Patriots">Patriots</option>
                            <option value="IPRC-Kigali">IPRC-Kigali</option>
                            <option value="REG">REG</option>
                            <option value="IPRC-SOUTH">IPRC-SOUTH</option>
                            <option value="UGB">UGB</option>
                            <option value="APR_BBC">APR BBC</option>
                        </select>
                    </div>
                    <h3>Score</h3>
                    <div class="form-group">
                        <input type="number" class="form-control" placeholder="Score" name="f_score" value="<?=$res[0]->f_score;?>">
                        <input type="number" class="form-control" placeholder="Score" name="s_score" value="<?=$res[0]->s_score;?>">
                    </div>
                    <br>
                    <br>
                    <button type="submit" class="btn btn-info btn-md">Submit</button>
                </form>
                <?php
            }
            else{
                ?>
                <div class="alert alert-warning">
                    <i class="fa fa-exclamation-circle"></i> The page you are requesting is not available.Please contact the WebMaster.
                </div>
                <?php
            }

        }
    }
}