<br>
<br>
<br>
<br>
<br>
<div class="container">
    <?php
    if(isset($_GET['cat'])){
        $cat=$_GET['cat'];
        require "class/Database.php";
        require "class/News.php";
        $datas=New News();
        $res=$datas->newsBy_Cat($cat);
        if($res){

            foreach ($res as $resu) {

                ?>
                    <div class="row">
                        <div class="col-lg-9">
                            <div class="news-cat">
                                <div class="row">
                                    <div class="col-lg-3">
                                        <img src="modules/covers/<?=$resu->cover_pic;?>" alt="" class="img-responsive img-thumbnail">
                                    </div>
                                    <div class="col-lg-9">
                                        <h3><a style="color:rgb(220,41,21);" href="index.php?p=read&amp;id=<?=$resu->id;?>"><?=$resu->title;?></a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
            }

        }
        else{
            ?>
            <div class="alert alert-warning">
                <p>There is no post in this category yet</p>
            </div>
            <?php
        }

    }
    else{
        header("Location:index.php?p=home");
    }
    ?>
</div>



