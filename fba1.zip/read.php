
    <?php
    if(isset($_GET['id'])){
        $id=$_GET['id'];
        require "class/Database.php";
        require "class/News.php";
        $datas=New News();
        $res=$datas->newsBy_Id($id);
        if($res){
            ?>
            <div class="page-header">
				<div class="wrapper-md container-fluid">
					<?=$res[0]->title;?>
				</div>
            </div>
			<div class="wrapper-md container-fluid">
				<div class="row">
					<div class="col-lg-8 col-md-8">
					<!-- start read container-->
					<div class="read-container">

						<div class="headline"><?=$res[0]->title;?></div>



						<div class="img">
							<img src="modules/covers/<?=$res[0]->cover_pic;?>">
						</div>

						<div class="share-container">
							<div class="sharethis-inline-share-buttons pull-left hid"></div>
						</div>
						<div class="counts pull-right">
							<button class="btn btn-sm"><i class="fa fa-eye"></i> <views>132</views>
							|  <i class="fa fa-comments-o"></i> 20 </button></div>
						</div>

						<div class="content">
						<?=$res[0]->content;?>
						</div>
					</div>
				</div>
			</div>


            <?php

        }
    }
    ?>
