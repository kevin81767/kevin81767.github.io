<?php
if(isset($_GET['id'])){
    $event_id=$_GET['id'];
    require 'class/Database.php';
    require 'class/Events.php';
    $event=New Events();

    $resu=$event->eventBy_Id($event_id);
    if($resu){
        ?>
        <br>
        <br>
        <br>
        <br>
        <div class="event-id">
            <h1><?=$resu[0]->title;?></h1>
            <p><?=$resu[0]->content;?></p>
        </div>
        <?php
    }
    else{
        ?>
        <div class="alert alert-warning">
            The page you are requesting is not available.
        </div>
        <?php
    }
}
else{
    header("Location:index.php?p=home");
}
?>

    <br>
    <br>
    <br>